import type { Schema, Struct } from '@strapi/strapi';

export interface SectionsButtonItem extends Struct.ComponentSchema {
  collectionName: 'components_sections_button_items';
  info: {
    displayName: 'Button Item';
    icon: 'cursor';
  };
  attributes: {
    href: Schema.Attribute.String & Schema.Attribute.Required;
    label: Schema.Attribute.String & Schema.Attribute.Required;
    style: Schema.Attribute.Enumeration<['primary', 'secondary']> &
      Schema.Attribute.DefaultTo<'primary'>;
  };
}

export interface SectionsButtonsBlock extends Struct.ComponentSchema {
  collectionName: 'components_sections_buttons_blocks';
  info: {
    displayName: 'Buttons';
    icon: 'cursor';
  };
  attributes: {
    align: Schema.Attribute.Enumeration<['left', 'center', 'right']> &
      Schema.Attribute.DefaultTo<'left'>;
    buttons: Schema.Attribute.Component<'sections.button-item', true>;
  };
}

export interface SectionsColumnItem extends Struct.ComponentSchema {
  collectionName: 'components_sections_column_items';
  info: {
    displayName: 'Column Item';
    icon: 'layout';
  };
  attributes: {
    heading: Schema.Attribute.String;
    image: Schema.Attribute.Media<'images'>;
    text: Schema.Attribute.Text;
  };
}

export interface SectionsColumnsBlock extends Struct.ComponentSchema {
  collectionName: 'components_sections_columns_blocks';
  info: {
    displayName: 'Columns';
    icon: 'layout';
  };
  attributes: {
    columns: Schema.Attribute.Component<'sections.column-item', true>;
    eyebrow: Schema.Attribute.String;
    heading: Schema.Attribute.String;
  };
}

export interface SectionsEmbed extends Struct.ComponentSchema {
  collectionName: 'components_sections_embeds';
  info: {
    displayName: 'Embed';
    icon: 'code';
  };
  attributes: {
    caption: Schema.Attribute.String;
    url: Schema.Attribute.String & Schema.Attribute.Required;
  };
}

export interface SectionsFeatureGrid extends Struct.ComponentSchema {
  collectionName: 'components_sections_feature_grids';
  info: {
    displayName: 'Feature Grid';
    icon: 'apps';
  };
  attributes: {
    eyebrow: Schema.Attribute.String;
    heading: Schema.Attribute.String;
    items: Schema.Attribute.Component<'sections.feature-item', true>;
  };
}

export interface SectionsFeatureItem extends Struct.ComponentSchema {
  collectionName: 'components_sections_feature_items';
  info: {
    displayName: 'Feature Item';
    icon: 'grid';
  };
  attributes: {
    icon: Schema.Attribute.String;
    image: Schema.Attribute.Media<'images'> &
      Schema.Attribute.SetPluginOptions<{
        i18n: {
          localized: false;
        };
      }>;
    text: Schema.Attribute.Text;
    title: Schema.Attribute.String & Schema.Attribute.Required;
  };
}

export interface SectionsGalleryBlock extends Struct.ComponentSchema {
  collectionName: 'components_sections_gallery_blocks';
  info: {
    displayName: 'Gallery';
    icon: 'grid';
  };
  attributes: {
    eyebrow: Schema.Attribute.String;
    heading: Schema.Attribute.String;
    images: Schema.Attribute.Media<'images', true> & Schema.Attribute.Required;
  };
}

export interface SectionsGlance extends Struct.ComponentSchema {
  collectionName: 'components_sections_glances';
  info: {
    displayName: 'At a Glance';
    icon: 'grid';
  };
  attributes: {
    cards: Schema.Attribute.Component<'sections.info-card', true>;
    glanceBody: Schema.Attribute.Text;
    glanceEyebrow: Schema.Attribute.String;
    glanceHeading: Schema.Attribute.String;
  };
}

export interface SectionsHero extends Struct.ComponentSchema {
  collectionName: 'components_sections_heroes';
  info: {
    displayName: 'Hero';
    icon: 'star';
  };
  attributes: {
    eyebrow: Schema.Attribute.String;
    headingLine1: Schema.Attribute.String & Schema.Attribute.Required;
    headingLine2: Schema.Attribute.String;
    image: Schema.Attribute.Media<'images'>;
    imageStyle: Schema.Attribute.Enumeration<
      ['disc-spin', 'plain', 'none', 'logo-3d']
    > &
      Schema.Attribute.DefaultTo<'disc-spin'>;
    primaryButtonHref: Schema.Attribute.String;
    primaryButtonLabel: Schema.Attribute.String;
    secondaryButtonHref: Schema.Attribute.String;
    secondaryButtonLabel: Schema.Attribute.String;
    subtitle: Schema.Attribute.Text;
  };
}

export interface SectionsImageBlock extends Struct.ComponentSchema {
  collectionName: 'components_sections_image_blocks';
  info: {
    displayName: 'Image';
    icon: 'picture';
  };
  attributes: {
    caption: Schema.Attribute.String;
    fullBleed: Schema.Attribute.Boolean & Schema.Attribute.DefaultTo<false>;
    href: Schema.Attribute.String;
    image: Schema.Attribute.Media<'images'> & Schema.Attribute.Required;
  };
}

export interface SectionsInfoCard extends Struct.ComponentSchema {
  collectionName: 'components_sections_info_cards';
  info: {
    displayName: 'Info Card';
    icon: 'layer';
  };
  attributes: {
    label: Schema.Attribute.String & Schema.Attribute.Required;
    text: Schema.Attribute.Text;
  };
}

export interface SectionsIntro extends Struct.ComponentSchema {
  collectionName: 'components_sections_intros';
  info: {
    displayName: 'Intro';
    icon: 'align-center';
  };
  attributes: {
    body: Schema.Attribute.Text;
    eyebrow: Schema.Attribute.String;
    heading: Schema.Attribute.String & Schema.Attribute.Required;
  };
}

export interface SectionsMission extends Struct.ComponentSchema {
  collectionName: 'components_sections_missions';
  info: {
    displayName: 'Mission';
    icon: 'quote';
  };
  attributes: {
    body: Schema.Attribute.Text;
    eyebrow: Schema.Attribute.String;
    heading: Schema.Attribute.String;
  };
}

export interface SectionsPullquote extends Struct.ComponentSchema {
  collectionName: 'components_sections_pullquotes';
  info: {
    displayName: 'Pullquote';
    icon: 'quote';
  };
  attributes: {
    author: Schema.Attribute.String;
    quote: Schema.Attribute.Text & Schema.Attribute.Required;
    role: Schema.Attribute.String;
  };
}

export interface SectionsRichText extends Struct.ComponentSchema {
  collectionName: 'components_sections_rich_texts';
  info: {
    displayName: 'Rich Text';
    icon: 'align-left';
  };
  attributes: {
    content: Schema.Attribute.Blocks;
    eyebrow: Schema.Attribute.String;
    heading: Schema.Attribute.String;
    width: Schema.Attribute.Enumeration<['narrow', 'wide']> &
      Schema.Attribute.DefaultTo<'narrow'>;
  };
}

export interface SectionsSlideItem extends Struct.ComponentSchema {
  collectionName: 'components_sections_slide_items';
  info: {
    displayName: 'Slide Item';
    icon: 'picture';
  };
  attributes: {
    caption: Schema.Attribute.String;
    image: Schema.Attribute.Media<'images'> & Schema.Attribute.Required;
  };
}

export interface SectionsSliderBlock extends Struct.ComponentSchema {
  collectionName: 'components_sections_slider_blocks';
  info: {
    displayName: 'Slider';
    icon: 'layer';
  };
  attributes: {
    eyebrow: Schema.Attribute.String;
    heading: Schema.Attribute.String;
    slides: Schema.Attribute.Component<'sections.slide-item', true>;
  };
}

export interface SectionsSpacer extends Struct.ComponentSchema {
  collectionName: 'components_sections_spacers';
  info: {
    displayName: 'Spacer';
    icon: 'arrows-expand';
  };
  attributes: {
    size: Schema.Attribute.Enumeration<['sm', 'md', 'lg', 'xl']> &
      Schema.Attribute.DefaultTo<'md'>;
  };
}

export interface SectionsStatItem extends Struct.ComponentSchema {
  collectionName: 'components_sections_stat_items';
  info: {
    displayName: 'Stat Item';
    icon: 'chart-bar';
  };
  attributes: {
    label: Schema.Attribute.String & Schema.Attribute.Required;
    value: Schema.Attribute.String & Schema.Attribute.Required;
  };
}

export interface SectionsStatsBand extends Struct.ComponentSchema {
  collectionName: 'components_sections_stats_bands';
  info: {
    displayName: 'Stats Band';
    icon: 'chart-pie';
  };
  attributes: {
    dark: Schema.Attribute.Boolean & Schema.Attribute.DefaultTo<true>;
    eyebrow: Schema.Attribute.String;
    heading: Schema.Attribute.String;
    stats: Schema.Attribute.Component<'sections.stat-item', true>;
  };
}

export interface SectionsStoryPanel extends Struct.ComponentSchema {
  collectionName: 'components_sections_story_panels';
  info: {
    displayName: 'Story + Panel';
    icon: 'picture';
  };
  attributes: {
    bodyParagraph1: Schema.Attribute.Text;
    bodyParagraph2: Schema.Attribute.Text;
    eyebrow: Schema.Attribute.String;
    heading: Schema.Attribute.String;
    panelBadge: Schema.Attribute.String;
    panelText: Schema.Attribute.Text;
    panelTitle: Schema.Attribute.String;
  };
}

export interface SectionsTeamGrid extends Struct.ComponentSchema {
  collectionName: 'components_sections_team_grids';
  info: {
    displayName: 'Team Grid';
    icon: 'user';
  };
  attributes: {
    eyebrow: Schema.Attribute.String;
    heading: Schema.Attribute.String;
    members: Schema.Attribute.Component<'sections.team-member', true>;
  };
}

export interface SectionsTeamMember extends Struct.ComponentSchema {
  collectionName: 'components_sections_team_members';
  info: {
    displayName: 'Team Member';
    icon: 'user';
  };
  attributes: {
    experience: Schema.Attribute.Text;
    name: Schema.Attribute.String & Schema.Attribute.Required;
    qualification: Schema.Attribute.String;
    role: Schema.Attribute.String;
  };
}

export interface SectionsVideo extends Struct.ComponentSchema {
  collectionName: 'components_sections_videos';
  info: {
    displayName: 'Video';
    icon: 'play';
  };
  attributes: {
    caption: Schema.Attribute.Text;
    eyebrow: Schema.Attribute.String;
    heading: Schema.Attribute.String;
    poster: Schema.Attribute.Media<'images'>;
    video: Schema.Attribute.Media<'videos'>;
  };
}

declare module '@strapi/strapi' {
  export namespace Public {
    export interface ComponentSchemas {
      'sections.button-item': SectionsButtonItem;
      'sections.buttons-block': SectionsButtonsBlock;
      'sections.column-item': SectionsColumnItem;
      'sections.columns-block': SectionsColumnsBlock;
      'sections.embed': SectionsEmbed;
      'sections.feature-grid': SectionsFeatureGrid;
      'sections.feature-item': SectionsFeatureItem;
      'sections.gallery-block': SectionsGalleryBlock;
      'sections.glance': SectionsGlance;
      'sections.hero': SectionsHero;
      'sections.image-block': SectionsImageBlock;
      'sections.info-card': SectionsInfoCard;
      'sections.intro': SectionsIntro;
      'sections.mission': SectionsMission;
      'sections.pullquote': SectionsPullquote;
      'sections.rich-text': SectionsRichText;
      'sections.slide-item': SectionsSlideItem;
      'sections.slider-block': SectionsSliderBlock;
      'sections.spacer': SectionsSpacer;
      'sections.stat-item': SectionsStatItem;
      'sections.stats-band': SectionsStatsBand;
      'sections.story-panel': SectionsStoryPanel;
      'sections.team-grid': SectionsTeamGrid;
      'sections.team-member': SectionsTeamMember;
      'sections.video': SectionsVideo;
    }
  }
}
