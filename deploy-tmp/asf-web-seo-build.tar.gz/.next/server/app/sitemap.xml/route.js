var R=require("../../chunks/[turbopack]_runtime.js")("server/app/sitemap.xml/route.js")
R.c("server/chunks/[root-of-the-server]__17bcnhv._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/apps_web__next-internal_server_app_sitemap_xml_route_actions_1z-i42-.js")
R.m(40201)
module.exports=R.m(40201).exports
