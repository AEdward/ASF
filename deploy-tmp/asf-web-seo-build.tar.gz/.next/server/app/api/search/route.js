var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/search/route.js")
R.c("server/chunks/[root-of-the-server]__0gn55sj._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_01_h63h._.js")
R.c("server/chunks/apps_web__next-internal_server_app_api_search_route_actions_1pfftxq.js")
R.m(53742)
module.exports=R.m(53742).exports
