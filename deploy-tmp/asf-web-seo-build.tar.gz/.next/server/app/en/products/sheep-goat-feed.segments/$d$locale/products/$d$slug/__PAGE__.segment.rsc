1:"$Sreact.fragment"
2:I[77105,["/_next/static/chunks/2dru2glu73-eh.js","/_next/static/chunks/14xmgymk1sega.js"],"default"]
3:I[5500,["/_next/static/chunks/2dru2glu73-eh.js","/_next/static/chunks/14xmgymk1sega.js"],"Image"]
4:I[97367,["/_next/static/chunks/3fntmmi971322.js"],"OutletBoundary"]
5:"$Sreact.suspense"
9:I[97367,["/_next/static/chunks/3fntmmi971322.js"],"ViewportBoundary"]
a:I[97367,["/_next/static/chunks/3fntmmi971322.js"],"MetadataBoundary"]
8:X
19:X
19:C
0:{"buildId":"fHhRWd-NoCwSpf___tmoY","data":[{"rsc":["$","$1","c",{"children":[["$","main",null,{"children":[["$","script",null,{"type":"application/ld+json","dangerouslySetInnerHTML":{"__html":"{\"@context\":\"https://schema.org\",\"@type\":\"Product\",\"name\":\"Sheep & Goat Feed\",\"description\":\"Formulated feed for sheep and goat farmers, part of ASF's livestock feed range.\",\"url\":\"https://asfagro.com/en/products/sheep-goat-feed\",\"image\":[\"http://localhost:1691/uploads/sheep_goat_feed_9938bdff62.webp\"],\"brand\":{\"@type\":\"Brand\",\"name\":\"ASF Agro Industry\"}}"}}],["$","script",null,{"type":"application/ld+json","dangerouslySetInnerHTML":{"__html":"{\"@context\":\"https://schema.org\",\"@type\":\"BreadcrumbList\",\"itemListElement\":[{\"@type\":\"ListItem\",\"position\":1,\"name\":\"Home\",\"item\":\"https://asfagro.com/en\"},{\"@type\":\"ListItem\",\"position\":2,\"name\":\"Products\",\"item\":\"https://asfagro.com/en/products\"},{\"@type\":\"ListItem\",\"position\":3,\"name\":\"Sheep & Goat Feed\",\"item\":\"https://asfagro.com/en/products/sheep-goat-feed\"}]}"}}],["$","section",null,{"className":"bg-[linear-gradient(135deg,#f5fff0,#fffaf0)] py-20","children":["$","div",null,{"className":"mx-auto max-w-5xl px-5 lg:px-8","children":[["$","$L2",null,{"href":"/en/products","localeCookie":{"name":"NEXT_LOCALE","sameSite":"lax"},"className":"text-sm font-bold text-green-700","children":"← Back to products"}],["$","div",null,{"className":"mb-4 flex items-center gap-2 text-xs font-black uppercase tracking-[.15em] text-green-700","children":[["$","span",null,{"className":"h-1 w-7 rounded bg-[#f5a617]"}],"CURRENT"]}],["$","h1",null,{"className":"max-w-3xl text-4xl font-black tracking-tight sm:text-5xl","children":"Sheep & Goat Feed"}],["$","p",null,{"className":"mt-6 max-w-2xl text-lg text-slate-600","children":"Formulated feed for sheep and goat farmers, part of ASF's livestock feed range."}]]}]}],["$","section",null,{"className":"py-16","children":["$","div",null,{"className":"mx-auto grid max-w-5xl gap-12 px-5 lg:grid-cols-2 lg:px-8","children":[["$","div",null,{"children":["$","div",null,{"className":"relative aspect-square overflow-hidden rounded-3xl bg-white","children":["$","$L3",null,{"src":"http://localhost:1691/uploads/sheep_goat_feed_9938bdff62.webp","alt":"Sheep & Goat Feed — ASF Agro Industry animal feed product","fill":true,"className":"object-contain p-6"}]}]}],["$","div",null,{"children":[false,"$undefined",["$","div",null,{"className":"mt-10","children":["$","$L2",null,{"href":"/en/contact","localeCookie":"$0:data:0:rsc:props:children:0:props:children:2:props:children:props:children:0:props:localeCookie","className":"inline-flex rounded-xl px-5 py-3 text-sm font-extrabold bg-[#58c900] text-[#092713]","children":"Request a quote →"}]}]]}]]}]}],false]}],null,["$","$L4",null,{"children":["$","$5",null,{"name":"Next.MetadataOutlet","children":"$@6"}]}]]}],"isPartial":"$@7","staleTime":"$8","varyParams":null},{"rsc":["$","$1","h",{"children":[null,["$","$L9",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$La",null,{"children":["$","$5",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"Sheep & Goat Feed | ASF Agro Industry"}],["$","meta","1",{"name":"description","content":"Formulated feed for sheep and goat farmers, part of ASF's livestock feed range."}],["$","link","2",{"rel":"canonical","href":"https://asfagro.com/en/products/sheep-goat-feed"}],["$","link","3",{"rel":"alternate","hrefLang":"en","href":"https://asfagro.com/en/products/sheep-goat-feed"}],["$","link","4",{"rel":"alternate","hrefLang":"am","href":"https://asfagro.com/am/products/sheep-goat-feed"}],["$","link","5",{"rel":"alternate","hrefLang":"om","href":"https://asfagro.com/om/products/sheep-goat-feed"}],["$","link","6",{"rel":"alternate","hrefLang":"x-default","href":"https://asfagro.com/en/products/sheep-goat-feed"}],["$","meta","7",{"property":"og:title","content":"Sheep & Goat Feed"}],["$","meta","8",{"property":"og:description","content":"Formulated feed for sheep and goat farmers, part of ASF's livestock feed range."}],["$","meta","9",{"property":"og:url","content":"https://asfagro.com/en/products/sheep-goat-feed"}],"$Lb","$Lc","$Ld","$Le","$Lf","$L10","$L11","$L12","$L13","$L14"]}]}]}],"$L15"]}],"isPartial":"$@16","staleTime":"$8","varyParams":null},{"rsc":"$L17","isPartial":"$@18","staleTime":"$8","varyParams":"$19"},{"rsc":"$L1a","isPartial":"$@1b","staleTime":"$8","varyParams":"$19"}],"isUpgradeableISRFallback":false,"a":"$@1c","rootVaryParams":null,"needsRuntimeRequest":"$@1d"}
1e:I[27201,["/_next/static/chunks/3fntmmi971322.js"],"IconMark"]
1f:I[39756,["/_next/static/chunks/3fntmmi971322.js"],"default"]
20:I[37457,["/_next/static/chunks/3fntmmi971322.js"],"default"]
6:null
b:["$","meta","10",{"property":"og:site_name","content":"ASF Agro Industry"}]
c:["$","meta","11",{"property":"og:locale","content":"en"}]
d:["$","meta","12",{"property":"og:image","content":"http://localhost:1691/uploads/sheep_goat_feed_9938bdff62.webp"}]
e:["$","meta","13",{"property":"og:type","content":"website"}]
f:["$","meta","14",{"name":"twitter:card","content":"summary_large_image"}]
10:["$","meta","15",{"name":"twitter:title","content":"Sheep & Goat Feed"}]
11:["$","meta","16",{"name":"twitter:description","content":"Formulated feed for sheep and goat farmers, part of ASF's livestock feed range."}]
12:["$","meta","17",{"name":"twitter:image","content":"http://localhost:1691/uploads/sheep_goat_feed_9938bdff62.webp"}]
13:["$","link","18",{"rel":"icon","href":"/asf-logo.png"}]
14:["$","$L1e","19",{}]
15:["$","meta",null,{"name":"next-size-adjust","content":""}]
17:["$","$1","c",{"children":[null,["$","$L1f",null,{"parallelRouterKey":"children","template":["$","$L20",null,{}]}]]}]
1a:["$","$1","c",{"children":[null,["$","$L1f",null,{"parallelRouterKey":"children","template":["$","$L20",null,{}]}]]}]
1d:true
8:300
8:C
1c:0
16:"$undefined"
18:"$undefined"
1b:"$undefined"
7:"$undefined"
