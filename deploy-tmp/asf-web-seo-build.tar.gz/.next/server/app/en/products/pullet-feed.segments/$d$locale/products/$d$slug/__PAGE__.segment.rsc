1:"$Sreact.fragment"
2:I[77105,["/_next/static/chunks/2dru2glu73-eh.js","/_next/static/chunks/14xmgymk1sega.js"],"default"]
3:I[5500,["/_next/static/chunks/2dru2glu73-eh.js","/_next/static/chunks/14xmgymk1sega.js"],"Image"]
4:I[97367,["/_next/static/chunks/3fntmmi971322.js"],"OutletBoundary"]
5:"$Sreact.suspense"
9:I[97367,["/_next/static/chunks/3fntmmi971322.js"],"ViewportBoundary"]
a:I[97367,["/_next/static/chunks/3fntmmi971322.js"],"MetadataBoundary"]
8:X
16:X
16:C
0:{"buildId":"fHhRWd-NoCwSpf___tmoY","data":[{"rsc":["$","$1","c",{"children":[["$","main",null,{"children":[["$","script",null,{"type":"application/ld+json","dangerouslySetInnerHTML":{"__html":"{\"@context\":\"https://schema.org\",\"@type\":\"Product\",\"name\":\"Pullet Feed\",\"description\":\"Formulated feed for pullets, part of ASF's poultry feed range.\",\"url\":\"https://asfagro.com/en/products/pullet-feed\",\"image\":[\"http://localhost:1691/uploads/pullet_feed_827a852178.webp\"],\"brand\":{\"@type\":\"Brand\",\"name\":\"ASF Agro Industry\"}}"}}],["$","script",null,{"type":"application/ld+json","dangerouslySetInnerHTML":{"__html":"{\"@context\":\"https://schema.org\",\"@type\":\"BreadcrumbList\",\"itemListElement\":[{\"@type\":\"ListItem\",\"position\":1,\"name\":\"Home\",\"item\":\"https://asfagro.com/en\"},{\"@type\":\"ListItem\",\"position\":2,\"name\":\"Products\",\"item\":\"https://asfagro.com/en/products\"},{\"@type\":\"ListItem\",\"position\":3,\"name\":\"Pullet Feed\",\"item\":\"https://asfagro.com/en/products/pullet-feed\"}]}"}}],["$","section",null,{"className":"bg-[linear-gradient(135deg,#f5fff0,#fffaf0)] py-20","children":["$","div",null,{"className":"mx-auto max-w-5xl px-5 lg:px-8","children":[["$","$L2",null,{"href":"/en/products","localeCookie":{"name":"NEXT_LOCALE","sameSite":"lax"},"className":"text-sm font-bold text-green-700","children":"← Back to products"}],["$","div",null,{"className":"mb-4 flex items-center gap-2 text-xs font-black uppercase tracking-[.15em] text-green-700","children":[["$","span",null,{"className":"h-1 w-7 rounded bg-[#f5a617]"}],"CURRENT"]}],["$","h1",null,{"className":"max-w-3xl text-4xl font-black tracking-tight sm:text-5xl","children":"Pullet Feed"}],["$","p",null,{"className":"mt-6 max-w-2xl text-lg text-slate-600","children":"Formulated feed for pullets, part of ASF's poultry feed range."}]]}]}],["$","section",null,{"className":"py-16","children":["$","div",null,{"className":"mx-auto grid max-w-5xl gap-12 px-5 lg:grid-cols-2 lg:px-8","children":[["$","div",null,{"children":["$","div",null,{"className":"relative aspect-square overflow-hidden rounded-3xl bg-white","children":["$","$L3",null,{"src":"http://localhost:1691/uploads/pullet_feed_827a852178.webp","alt":"Pullet Feed — ASF Agro Industry animal feed product","fill":true,"className":"object-contain p-6"}]}]}],["$","div",null,{"children":[false,"$undefined",["$","div",null,{"className":"mt-10","children":["$","$L2",null,{"href":"/en/contact","localeCookie":"$0:data:0:rsc:props:children:0:props:children:2:props:children:props:children:0:props:localeCookie","className":"inline-flex rounded-xl px-5 py-3 text-sm font-extrabold bg-[#58c900] text-[#092713]","children":"Request a quote →"}]}]]}]]}]}],false]}],null,["$","$L4",null,{"children":["$","$5",null,{"name":"Next.MetadataOutlet","children":"$@6"}]}]]}],"isPartial":"$@7","staleTime":"$8","varyParams":null},{"rsc":["$","$1","h",{"children":[null,["$","$L9",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$La",null,{"children":["$","$5",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"Pullet Feed | ASF Agro Industry"}],["$","meta","1",{"name":"description","content":"Formulated feed for pullets, part of ASF's poultry feed range."}],["$","link","2",{"rel":"canonical","href":"https://asfagro.com/en/products/pullet-feed"}],["$","link","3",{"rel":"alternate","hrefLang":"en","href":"https://asfagro.com/en/products/pullet-feed"}],["$","link","4",{"rel":"alternate","hrefLang":"am","href":"https://asfagro.com/am/products/pullet-feed"}],["$","link","5",{"rel":"alternate","hrefLang":"om","href":"https://asfagro.com/om/products/pullet-feed"}],["$","link","6",{"rel":"alternate","hrefLang":"x-default","href":"https://asfagro.com/en/products/pullet-feed"}],["$","meta","7",{"property":"og:title","content":"Pullet Feed"}],["$","meta","8",{"property":"og:description","content":"Formulated feed for pullets, part of ASF's poultry feed range."}],["$","meta","9",{"property":"og:url","content":"https://asfagro.com/en/products/pullet-feed"}],["$","meta","10",{"property":"og:site_name","content":"ASF Agro Industry"}],["$","meta","11",{"property":"og:locale","content":"en"}],["$","meta","12",{"property":"og:image","content":"http://localhost:1691/uploads/pullet_feed_827a852178.webp"}],"$Lb","$Lc","$Ld","$Le","$Lf","$L10","$L11"]}]}]}],"$L12"]}],"isPartial":"$@13","staleTime":"$8","varyParams":null},{"rsc":"$L14","isPartial":"$@15","staleTime":"$8","varyParams":"$16"},{"rsc":"$L17","isPartial":"$@18","staleTime":"$8","varyParams":"$16"}],"isUpgradeableISRFallback":false,"a":"$@19","rootVaryParams":null,"needsRuntimeRequest":"$@1a"}
1b:I[27201,["/_next/static/chunks/3fntmmi971322.js"],"IconMark"]
1c:I[39756,["/_next/static/chunks/3fntmmi971322.js"],"default"]
1d:I[37457,["/_next/static/chunks/3fntmmi971322.js"],"default"]
6:null
b:["$","meta","13",{"property":"og:type","content":"website"}]
c:["$","meta","14",{"name":"twitter:card","content":"summary_large_image"}]
d:["$","meta","15",{"name":"twitter:title","content":"Pullet Feed"}]
e:["$","meta","16",{"name":"twitter:description","content":"Formulated feed for pullets, part of ASF's poultry feed range."}]
f:["$","meta","17",{"name":"twitter:image","content":"http://localhost:1691/uploads/pullet_feed_827a852178.webp"}]
10:["$","link","18",{"rel":"icon","href":"/asf-logo.png"}]
11:["$","$L1b","19",{}]
12:["$","meta",null,{"name":"next-size-adjust","content":""}]
14:["$","$1","c",{"children":[null,["$","$L1c",null,{"parallelRouterKey":"children","template":["$","$L1d",null,{}]}]]}]
17:["$","$1","c",{"children":[null,["$","$L1c",null,{"parallelRouterKey":"children","template":["$","$L1d",null,{}]}]]}]
1a:true
8:300
8:C
19:0
13:"$undefined"
15:"$undefined"
18:"$undefined"
7:"$undefined"
