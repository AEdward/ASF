1:"$Sreact.fragment"
2:I[19049,["/_next/static/chunks/2dru2glu73-eh.js","/_next/static/chunks/14xmgymk1sega.js","/_next/static/chunks/35kf7xylhynjn.js"],"ContactForm"]
3:I[97367,["/_next/static/chunks/3fntmmi971322.js"],"OutletBoundary"]
4:"$Sreact.suspense"
8:I[97367,["/_next/static/chunks/3fntmmi971322.js"],"ViewportBoundary"]
9:I[97367,["/_next/static/chunks/3fntmmi971322.js"],"MetadataBoundary"]
7:X
1e:X
1e:C
0:{"buildId":"fHhRWd-NoCwSpf___tmoY","data":[{"rsc":["$","$1","c",{"children":[["$","main",null,{"children":[["$","script",null,{"type":"application/ld+json","dangerouslySetInnerHTML":{"__html":"{\"@context\":\"https://schema.org\",\"@type\":\"BreadcrumbList\",\"itemListElement\":[{\"@type\":\"ListItem\",\"position\":1,\"name\":\"Home\",\"item\":\"https://asfagro.com/en\"},{\"@type\":\"ListItem\",\"position\":2,\"name\":\"Contact\",\"item\":\"https://asfagro.com/en/contact\"}]}"}}],["$","section",null,{"className":"bg-[linear-gradient(135deg,#f5fff0,#fffaf0)] py-20","children":["$","div",null,{"className":"mx-auto max-w-7xl px-5 lg:px-8","children":[["$","div",null,{"className":"mb-4 flex items-center gap-2 text-xs font-black uppercase tracking-[.15em] text-green-700","children":[["$","span",null,{"className":"h-1 w-7 rounded bg-[#f5a617]"}],"Contact ASF"]}],["$","h1",null,{"className":"max-w-4xl text-5xl font-black tracking-tight sm:text-6xl","children":"Let's build the agricultural future together."}],["$","p",null,{"className":"mt-6 max-w-2xl text-lg text-slate-600","children":"For partnerships, feed supply, business development and other enquiries, contact the ASF team."}]]}]}],["$","section",null,{"className":"py-24","children":[["$","div",null,{"className":"mx-auto grid max-w-7xl gap-6 px-5 lg:grid-cols-2 lg:px-8","children":[["$","div",null,{"className":"rounded-3xl border p-8","children":[["$","div",null,{"className":"mb-4 flex items-center gap-2 text-xs font-black uppercase tracking-[.15em] text-green-700","children":[["$","span",null,{"className":"h-1 w-7 rounded bg-[#f5a617]"}],"Company details"]}],["$","h2",null,{"className":"text-3xl font-black","children":"Reach our team."}],["$","div",null,{"className":"mt-7 space-y-3","children":[["$","div","Head Office",{"className":"rounded-2xl bg-slate-50 p-4","children":[["$","b",null,{"className":"block text-xs uppercase tracking-widest text-green-700","children":"Head Office"}],["$","span",null,{"children":"Akaki Kality Woreda 05, near Kality Maseltegna, Addis Ababa, Ethiopia"}]]}],["$","div","Operational Factory",{"className":"rounded-2xl bg-slate-50 p-4","children":[["$","b",null,{"className":"block text-xs uppercase tracking-widest text-green-700","children":"Operational Factory"}],["$","span",null,{"children":"Operational Factory: Tulu Bolo Town, South West Shoa Zone, Oromia Region. Warehouse: Welete, Sheger City."}]]}],["$","div","Expansion Site",{"className":"rounded-2xl bg-slate-50 p-4","children":[["$","b",null,{"className":"block text-xs uppercase tracking-widest text-green-700","children":"Expansion Site"}],["$","span",null,{"children":"Expansion site (in progress): Bulbula Integrated Agro Industry Park, 160km south of Addis Ababa, near Zeway City on the highway to Hawassa."}]]}],["$","div","Phone",{"className":"rounded-2xl bg-slate-50 p-4","children":[["$","b",null,{"className":"block text-xs uppercase tracking-widest text-green-700","children":"Phone"}],["$","span",null,{"children":"0976177236 · 0911540903 / 0911200732"}]]}],["$","div","Email",{"className":"rounded-2xl bg-slate-50 p-4","children":[["$","b",null,{"className":"block text-xs uppercase tracking-widest text-green-700","children":"Email"}],["$","span",null,{"children":"merihun@asfagro.com · argaw@asfagro.com"}]]}]]}]]}],["$","$L2",null,{}]]}],null]}]]}],[["$","script","script-0",{"src":"/_next/static/chunks/35kf7xylhynjn.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":"$@6","staleTime":"$7","varyParams":null},{"rsc":["$","$1","h",{"children":[null,["$","$L8",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L9",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"Contact | ASF Agro Industry"}],["$","meta","1",{"name":"description","content":"Contact the ASF Agro Industry team for partnerships and enquiries."}],["$","link","2",{"rel":"canonical","href":"https://asfagro.com/en/contact"}],["$","link","3",{"rel":"alternate","hrefLang":"en","href":"https://asfagro.com/en/contact"}],"$La","$Lb","$Lc","$Ld","$Le","$Lf","$L10","$L11","$L12","$L13","$L14","$L15","$L16","$L17","$L18","$L19"]}]}]}],"$L1a"]}],"isPartial":"$@1b","staleTime":"$7","varyParams":null},{"rsc":"$L1c","isPartial":"$@1d","staleTime":"$7","varyParams":"$1e"}],"isUpgradeableISRFallback":false,"a":"$@1f","rootVaryParams":null,"needsRuntimeRequest":"$@20"}
21:I[27201,["/_next/static/chunks/3fntmmi971322.js"],"IconMark"]
22:I[39756,["/_next/static/chunks/3fntmmi971322.js"],"default"]
23:I[37457,["/_next/static/chunks/3fntmmi971322.js"],"default"]
5:null
a:["$","link","4",{"rel":"alternate","hrefLang":"am","href":"https://asfagro.com/am/contact"}]
b:["$","link","5",{"rel":"alternate","hrefLang":"om","href":"https://asfagro.com/om/contact"}]
c:["$","link","6",{"rel":"alternate","hrefLang":"x-default","href":"https://asfagro.com/en/contact"}]
d:["$","meta","7",{"property":"og:title","content":"Contact"}]
e:["$","meta","8",{"property":"og:description","content":"Contact the ASF Agro Industry team for partnerships and enquiries."}]
f:["$","meta","9",{"property":"og:url","content":"https://asfagro.com/en/contact"}]
10:["$","meta","10",{"property":"og:site_name","content":"ASF Agro Industry"}]
11:["$","meta","11",{"property":"og:locale","content":"en"}]
12:["$","meta","12",{"property":"og:image","content":"https://asfagro.com/asf-logo.png"}]
13:["$","meta","13",{"property":"og:type","content":"website"}]
14:["$","meta","14",{"name":"twitter:card","content":"summary_large_image"}]
15:["$","meta","15",{"name":"twitter:title","content":"Contact"}]
16:["$","meta","16",{"name":"twitter:description","content":"Contact the ASF Agro Industry team for partnerships and enquiries."}]
17:["$","meta","17",{"name":"twitter:image","content":"https://asfagro.com/asf-logo.png"}]
18:["$","link","18",{"rel":"icon","href":"/asf-logo.png"}]
19:["$","$L21","19",{}]
1a:["$","meta",null,{"name":"next-size-adjust","content":""}]
1c:["$","$1","c",{"children":[null,["$","$L22",null,{"parallelRouterKey":"children","template":["$","$L23",null,{}]}]]}]
20:true
7:300
7:C
1f:0
1b:"$undefined"
1d:"$undefined"
6:"$undefined"
