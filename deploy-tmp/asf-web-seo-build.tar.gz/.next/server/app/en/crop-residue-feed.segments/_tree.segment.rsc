:HL["/_next/static/chunks/091d8xk9dnzee.css","style"]
:HL["/_next/static/media/276ff8de80749a43-s.p.29e-66-z_wi5x.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"locale","param":{"type":"d","key":"en","siblings":["api"]},"prefetchHints":4144,"slots":{"children":{"name":"crop-residue-feed","param":null,"prefetchHints":4160,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}}}},"staleTime":300,"buildId":"fHhRWd-NoCwSpf___tmoY"}
