1:"$Sreact.fragment"
2:I[77105,["/_next/static/chunks/2dru2glu73-eh.js","/_next/static/chunks/14xmgymk1sega.js"],"default"]
3:I[97367,["/_next/static/chunks/3fntmmi971322.js"],"OutletBoundary"]
4:"$Sreact.suspense"
8:I[97367,["/_next/static/chunks/3fntmmi971322.js"],"ViewportBoundary"]
9:I[97367,["/_next/static/chunks/3fntmmi971322.js"],"MetadataBoundary"]
7:X
1a:X
1a:C
0:{"buildId":"fHhRWd-NoCwSpf___tmoY","data":[{"rsc":["$","$1","c",{"children":[["$","main",null,{"children":[["$","script",null,{"type":"application/ld+json","dangerouslySetInnerHTML":{"__html":"{\"@context\":\"https://schema.org\",\"@type\":\"Article\",\"headline\":\"ASF's next chapter at Bulbula Integrated Agro Industry Park\",\"description\":\"In February 2023, ASF signed an investment agreement for a 271-hectare site at the Bulbula Integrated Agro Industry Park, 160km south of Addis Ababa, laying the groundwork for the company's next phase of growth.\",\"url\":\"https://asfagro.com/en/blog/next-chapter-at-bulbula\",\"publisher\":{\"@type\":\"Organization\",\"name\":\"ASF Agro Industry\",\"logo\":{\"@type\":\"ImageObject\",\"url\":\"https://asfagro.com/asf-logo.png\"}}}"}}],["$","script",null,{"type":"application/ld+json","dangerouslySetInnerHTML":{"__html":"{\"@context\":\"https://schema.org\",\"@type\":\"BreadcrumbList\",\"itemListElement\":[{\"@type\":\"ListItem\",\"position\":1,\"name\":\"Home\",\"item\":\"https://asfagro.com/en\"},{\"@type\":\"ListItem\",\"position\":2,\"name\":\"News & Blog\",\"item\":\"https://asfagro.com/en/blog\"},{\"@type\":\"ListItem\",\"position\":3,\"name\":\"ASF's next chapter at Bulbula Integrated Agro Industry Park\",\"item\":\"https://asfagro.com/en/blog/next-chapter-at-bulbula\"}]}"}}],["$","section",null,{"className":"bg-[linear-gradient(135deg,#f5fff0,#fffaf0)] py-20","children":["$","div",null,{"className":"mx-auto max-w-4xl px-5 lg:px-8","children":[["$","$L2",null,{"href":"/en/blog","localeCookie":{"name":"NEXT_LOCALE","sameSite":"lax"},"className":"text-sm font-bold text-green-700","children":"← Back to News & Blog"}],["$","div",null,{"className":"mb-4 flex items-center gap-2 text-xs font-black uppercase tracking-[.15em] text-green-700","children":[["$","span",null,{"className":"h-1 w-7 rounded bg-[#f5a617]"}],"Expansion"]}],["$","h1",null,{"className":"max-w-3xl text-4xl font-black tracking-tight sm:text-5xl","children":"ASF's next chapter at Bulbula Integrated Agro Industry Park"}]]}]}],"$undefined",["$","section",null,{"className":"py-16","children":["$","div",null,{"className":"mx-auto max-w-4xl px-5 lg:px-8","children":["$","div",null,{"className":"whitespace-pre-line text-lg leading-8 text-slate-700","children":"In February 2023, ASF signed an investment agreement for a 271-hectare site at the Bulbula Integrated Agro Industry Park, 160km south of Addis Ababa, laying the groundwork for the company's next phase of growth."}]}]}]]}],null,["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":"$@6","staleTime":"$7","varyParams":null},{"rsc":["$","$1","h",{"children":[null,["$","$L8",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L9",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"ASF's next chapter at Bulbula Integrated Agro Industry Park | ASF Agro Industry"}],["$","meta","1",{"name":"description","content":"In February 2023, ASF signed an investment agreement for a 271-hectare site at the Bulbula Integrated Agro Industry Park, 160km south of Addis Ababa, laying the groundwork for the company's next phase of growth."}],["$","link","2",{"rel":"canonical","href":"https://asfagro.com/en/blog/next-chapter-at-bulbula"}],["$","link","3",{"rel":"alternate","hrefLang":"en","href":"https://asfagro.com/en/blog/next-chapter-at-bulbula"}],["$","link","4",{"rel":"alternate","hrefLang":"am","href":"https://asfagro.com/am/blog/next-chapter-at-bulbula"}],["$","link","5",{"rel":"alternate","hrefLang":"om","href":"https://asfagro.com/om/blog/next-chapter-at-bulbula"}],["$","link","6",{"rel":"alternate","hrefLang":"x-default","href":"https://asfagro.com/en/blog/next-chapter-at-bulbula"}],["$","meta","7",{"property":"og:title","content":"ASF's next chapter at Bulbula Integrated Agro Industry Park"}],"$La","$Lb","$Lc","$Ld","$Le","$Lf","$L10","$L11","$L12","$L13","$L14","$L15"]}]}]}],"$L16"]}],"isPartial":"$@17","staleTime":"$7","varyParams":null},{"rsc":"$L18","isPartial":"$@19","staleTime":"$7","varyParams":"$1a"},{"rsc":"$L1b","isPartial":"$@1c","staleTime":"$7","varyParams":"$1a"}],"isUpgradeableISRFallback":false,"a":"$@1d","rootVaryParams":null,"needsRuntimeRequest":"$@1e"}
1f:I[27201,["/_next/static/chunks/3fntmmi971322.js"],"IconMark"]
20:I[39756,["/_next/static/chunks/3fntmmi971322.js"],"default"]
21:I[37457,["/_next/static/chunks/3fntmmi971322.js"],"default"]
5:null
a:["$","meta","8",{"property":"og:description","content":"In February 2023, ASF signed an investment agreement for a 271-hectare site at the Bulbula Integrated Agro Industry Park, 160km south of Addis Ababa, laying the groundwork for the company's next phase of growth."}]
b:["$","meta","9",{"property":"og:url","content":"https://asfagro.com/en/blog/next-chapter-at-bulbula"}]
c:["$","meta","10",{"property":"og:site_name","content":"ASF Agro Industry"}]
d:["$","meta","11",{"property":"og:locale","content":"en"}]
e:["$","meta","12",{"property":"og:image","content":"https://asfagro.com/asf-logo.png"}]
f:["$","meta","13",{"property":"og:type","content":"website"}]
10:["$","meta","14",{"name":"twitter:card","content":"summary_large_image"}]
11:["$","meta","15",{"name":"twitter:title","content":"ASF's next chapter at Bulbula Integrated Agro Industry Park"}]
12:["$","meta","16",{"name":"twitter:description","content":"In February 2023, ASF signed an investment agreement for a 271-hectare site at the Bulbula Integrated Agro Industry Park, 160km south of Addis Ababa, laying the groundwork for the company's next phase of growth."}]
13:["$","meta","17",{"name":"twitter:image","content":"https://asfagro.com/asf-logo.png"}]
14:["$","link","18",{"rel":"icon","href":"/asf-logo.png"}]
15:["$","$L1f","19",{}]
16:["$","meta",null,{"name":"next-size-adjust","content":""}]
18:["$","$1","c",{"children":[null,["$","$L20",null,{"parallelRouterKey":"children","template":["$","$L21",null,{}]}]]}]
1b:["$","$1","c",{"children":[null,["$","$L20",null,{"parallelRouterKey":"children","template":["$","$L21",null,{}]}]]}]
1e:true
7:300
7:C
1d:0
17:"$undefined"
19:"$undefined"
1c:"$undefined"
6:"$undefined"
