1:"$Sreact.fragment"
2:I[19049,["/_next/static/chunks/2dru2glu73-eh.js","/_next/static/chunks/14xmgymk1sega.js","/_next/static/chunks/35kf7xylhynjn.js"],"ContactForm"]
3:I[97367,["/_next/static/chunks/3fntmmi971322.js"],"OutletBoundary"]
4:"$Sreact.suspense"
8:I[97367,["/_next/static/chunks/3fntmmi971322.js"],"ViewportBoundary"]
9:I[97367,["/_next/static/chunks/3fntmmi971322.js"],"MetadataBoundary"]
7:X
1a:X
1a:C
0:{"buildId":"fHhRWd-NoCwSpf___tmoY","data":[{"rsc":["$","$1","c",{"children":[["$","main",null,{"children":[["$","script",null,{"type":"application/ld+json","dangerouslySetInnerHTML":{"__html":"{\"@context\":\"https://schema.org\",\"@type\":\"BreadcrumbList\",\"itemListElement\":[{\"@type\":\"ListItem\",\"position\":1,\"name\":\"መነሻ\",\"item\":\"https://asfagro.com/am\"},{\"@type\":\"ListItem\",\"position\":2,\"name\":\"አግኙን\",\"item\":\"https://asfagro.com/am/contact\"}]}"}}],["$","section",null,{"className":"bg-[linear-gradient(135deg,#f5fff0,#fffaf0)] py-20","children":["$","div",null,{"className":"mx-auto max-w-7xl px-5 lg:px-8","children":[["$","div",null,{"className":"mb-4 flex items-center gap-2 text-xs font-black uppercase tracking-[.15em] text-green-700","children":[["$","span",null,{"className":"h-1 w-7 rounded bg-[#f5a617]"}],"ASFን ያግኙ"]}],["$","h1",null,{"className":"max-w-4xl text-5xl font-black tracking-tight sm:text-6xl","children":"የግብርናውን የወደፊት ጊዜ በጋራ እንገንባ።"}],["$","p",null,{"className":"mt-6 max-w-2xl text-lg text-slate-600","children":"ለትብብር፣ የመኖ አቅርቦት፣ የስራ እድገት እና ለሌሎች ጥያቄዎች የASF ቡድንን ያግኙ።"}]]}]}],["$","section",null,{"className":"py-24","children":[["$","div",null,{"className":"mx-auto grid max-w-7xl gap-6 px-5 lg:grid-cols-2 lg:px-8","children":[["$","div",null,{"className":"rounded-3xl border p-8","children":[["$","div",null,{"className":"mb-4 flex items-center gap-2 text-xs font-black uppercase tracking-[.15em] text-green-700","children":[["$","span",null,{"className":"h-1 w-7 rounded bg-[#f5a617]"}],"የኩባንያ ዝርዝሮች"]}],["$","h2",null,{"className":"text-3xl font-black","children":"ቡድናችንን ያግኙ።"}],["$","div",null,{"className":"mt-7 space-y-3","children":[["$","div","ዋና መስሪያ ቤት",{"className":"rounded-2xl bg-slate-50 p-4","children":[["$","b",null,{"className":"block text-xs uppercase tracking-widest text-green-700","children":"ዋና መስሪያ ቤት"}],["$","span",null,{"children":"አቃቂ ቂሊጥ ወረዳ 05፣ ቂሊጥ መሠልጠኛ አካባቢ፣ አዲስ አበባ፣ ኢትዮጵያ"}]]}],["$","div","የማምረቻ ፋብሪካ",{"className":"rounded-2xl bg-slate-50 p-4","children":[["$","b",null,{"className":"block text-xs uppercase tracking-widest text-green-700","children":"የማምረቻ ፋብሪካ"}],["$","span",null,{"children":"ማምረቻ ፋብሪካ፦ ቱሉ ቦሎ ከተማ፣ ደቡብ ምዕራብ ሸዋ ዞን፣ ኦሮሚያ ክልል። መጋዘን፦ ወለቴ፣ ሸገር ከተማ።"}]]}],["$","div","የማስፋፊያ ቦታ",{"className":"rounded-2xl bg-slate-50 p-4","children":[["$","b",null,{"className":"block text-xs uppercase tracking-widest text-green-700","children":"የማስፋፊያ ቦታ"}],["$","span",null,{"children":"የማስፋፊያ ቦታ (በሂደት ላይ)፦ ቡልቡላ የተቀናጀ አግሮ ኢንዱስትሪ ፓርክ፣ ከአዲስ አበባ 160 ኪ.ሜ ደቡብ፣ በዘዋይ ከተማ አቅራቢያ በሃዋሳ መንገድ ላይ።"}]]}],["$","div","ስልክ",{"className":"rounded-2xl bg-slate-50 p-4","children":[["$","b",null,{"className":"block text-xs uppercase tracking-widest text-green-700","children":"ስልክ"}],["$","span",null,{"children":"0976177236 · 0911540903 / 0911200732"}]]}],["$","div","ኢሜይል",{"className":"rounded-2xl bg-slate-50 p-4","children":[["$","b",null,{"className":"block text-xs uppercase tracking-widest text-green-700","children":"ኢሜይል"}],["$","span",null,{"children":"merihun@asfagro.com · argaw@asfagro.com"}]]}]]}]]}],["$","$L2",null,{}]]}],null]}]]}],[["$","script","script-0",{"src":"/_next/static/chunks/35kf7xylhynjn.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":"$@6","staleTime":"$7","varyParams":null},{"rsc":["$","$1","h",{"children":[null,["$","$L8",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L9",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"አግኙን | ASF Agro Industry"}],["$","meta","1",{"name":"description","content":"ለትብብር እና ለጥያቄዎች የASF አግሮ ኢንዱስትሪ ቡድንን ያግኙ።"}],["$","link","2",{"rel":"canonical","href":"https://asfagro.com/am/contact"}],["$","link","3",{"rel":"alternate","hrefLang":"en","href":"https://asfagro.com/en/contact"}],["$","link","4",{"rel":"alternate","hrefLang":"am","href":"https://asfagro.com/am/contact"}],["$","link","5",{"rel":"alternate","hrefLang":"om","href":"https://asfagro.com/om/contact"}],["$","link","6",{"rel":"alternate","hrefLang":"x-default","href":"https://asfagro.com/en/contact"}],["$","meta","7",{"property":"og:title","content":"አግኙን"}],"$La","$Lb","$Lc","$Ld","$Le","$Lf","$L10","$L11","$L12","$L13","$L14","$L15"]}]}]}],"$L16"]}],"isPartial":"$@17","staleTime":"$7","varyParams":null},{"rsc":"$L18","isPartial":"$@19","staleTime":"$7","varyParams":"$1a"}],"isUpgradeableISRFallback":false,"a":"$@1b","rootVaryParams":null,"needsRuntimeRequest":"$@1c"}
1d:I[27201,["/_next/static/chunks/3fntmmi971322.js"],"IconMark"]
1e:I[39756,["/_next/static/chunks/3fntmmi971322.js"],"default"]
1f:I[37457,["/_next/static/chunks/3fntmmi971322.js"],"default"]
5:null
a:["$","meta","8",{"property":"og:description","content":"ለትብብር እና ለጥያቄዎች የASF አግሮ ኢንዱስትሪ ቡድንን ያግኙ።"}]
b:["$","meta","9",{"property":"og:url","content":"https://asfagro.com/am/contact"}]
c:["$","meta","10",{"property":"og:site_name","content":"ASF Agro Industry"}]
d:["$","meta","11",{"property":"og:locale","content":"am"}]
e:["$","meta","12",{"property":"og:image","content":"https://asfagro.com/asf-logo.png"}]
f:["$","meta","13",{"property":"og:type","content":"website"}]
10:["$","meta","14",{"name":"twitter:card","content":"summary_large_image"}]
11:["$","meta","15",{"name":"twitter:title","content":"አግኙን"}]
12:["$","meta","16",{"name":"twitter:description","content":"ለትብብር እና ለጥያቄዎች የASF አግሮ ኢንዱስትሪ ቡድንን ያግኙ።"}]
13:["$","meta","17",{"name":"twitter:image","content":"https://asfagro.com/asf-logo.png"}]
14:["$","link","18",{"rel":"icon","href":"/asf-logo.png"}]
15:["$","$L1d","19",{}]
16:["$","meta",null,{"name":"next-size-adjust","content":""}]
18:["$","$1","c",{"children":[null,["$","$L1e",null,{"parallelRouterKey":"children","template":["$","$L1f",null,{}]}]]}]
1c:true
7:300
7:C
1b:0
17:"$undefined"
19:"$undefined"
6:"$undefined"
