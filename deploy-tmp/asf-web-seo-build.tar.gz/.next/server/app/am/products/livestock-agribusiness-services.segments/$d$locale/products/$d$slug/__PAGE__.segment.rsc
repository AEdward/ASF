1:"$Sreact.fragment"
2:I[77105,["/_next/static/chunks/2dru2glu73-eh.js","/_next/static/chunks/14xmgymk1sega.js"],"default"]
3:I[97367,["/_next/static/chunks/3fntmmi971322.js"],"OutletBoundary"]
4:"$Sreact.suspense"
8:I[97367,["/_next/static/chunks/3fntmmi971322.js"],"ViewportBoundary"]
9:I[97367,["/_next/static/chunks/3fntmmi971322.js"],"MetadataBoundary"]
7:X
16:X
16:C
0:{"buildId":"fHhRWd-NoCwSpf___tmoY","data":[{"rsc":["$","$1","c",{"children":[["$","main",null,{"children":[["$","script",null,{"type":"application/ld+json","dangerouslySetInnerHTML":{"__html":"{\"@context\":\"https://schema.org\",\"@type\":\"Product\",\"name\":\"የእንስሳት እና አግሪቢዝነስ አገልግሎቶች\",\"description\":\"የታቀደ ለውጭ ገበያ ደረጃ የእንስሳት እርድ ቤት እና የእንስሳት መድሃኒት እና መገልገያ አቅርቦት።\",\"url\":\"https://asfagro.com/am/products/livestock-agribusiness-services\",\"brand\":{\"@type\":\"Brand\",\"name\":\"ASF Agro Industry\"}}"}}],["$","script",null,{"type":"application/ld+json","dangerouslySetInnerHTML":{"__html":"{\"@context\":\"https://schema.org\",\"@type\":\"BreadcrumbList\",\"itemListElement\":[{\"@type\":\"ListItem\",\"position\":1,\"name\":\"መነሻ\",\"item\":\"https://asfagro.com/am\"},{\"@type\":\"ListItem\",\"position\":2,\"name\":\"ምርቶች\",\"item\":\"https://asfagro.com/am/products\"},{\"@type\":\"ListItem\",\"position\":3,\"name\":\"የእንስሳት እና አግሪቢዝነስ አገልግሎቶች\",\"item\":\"https://asfagro.com/am/products/livestock-agribusiness-services\"}]}"}}],["$","section",null,{"className":"bg-[linear-gradient(135deg,#f5fff0,#fffaf0)] py-20","children":["$","div",null,{"className":"mx-auto max-w-5xl px-5 lg:px-8","children":[["$","$L2",null,{"href":"/am/products","localeCookie":{"name":"NEXT_LOCALE","sameSite":"lax"},"className":"text-sm font-bold text-green-700","children":"← ወደ ምርቶች ተመለስ"}],["$","div",null,{"className":"mb-4 flex items-center gap-2 text-xs font-black uppercase tracking-[.15em] text-green-700","children":[["$","span",null,{"className":"h-1 w-7 rounded bg-[#f5a617]"}],"የታቀደ"]}],["$","h1",null,{"className":"max-w-3xl text-4xl font-black tracking-tight sm:text-5xl","children":"የእንስሳት እና አግሪቢዝነስ አገልግሎቶች"}],["$","p",null,{"className":"mt-6 max-w-2xl text-lg text-slate-600","children":"የታቀደ ለውጭ ገበያ ደረጃ የእንስሳት እርድ ቤት እና የእንስሳት መድሃኒት እና መገልገያ አቅርቦት።"}]]}]}],["$","section",null,{"className":"py-16","children":["$","div",null,{"className":"mx-auto grid max-w-5xl gap-12 px-5 lg:grid-cols-2 lg:px-8","children":[["$","div",null,{"children":["$","div",null,{"className":"flex aspect-square items-center justify-center rounded-3xl bg-slate-100 text-slate-400","children":"የእንስሳት እና አግሪቢዝነስ አገልግሎቶች"}]}],["$","div",null,{"children":[false,"$undefined",["$","div",null,{"className":"mt-10","children":["$","$L2",null,{"href":"/am/contact","localeCookie":"$0:data:0:rsc:props:children:0:props:children:2:props:children:props:children:0:props:localeCookie","className":"inline-flex rounded-xl px-5 py-3 text-sm font-extrabold bg-[#58c900] text-[#092713]","children":"የዋጋ ጥቆማ ይጠይቁ →"}]}]]}]]}]}],false]}],null,["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":"$@6","staleTime":"$7","varyParams":null},{"rsc":["$","$1","h",{"children":[null,["$","$L8",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L9",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"የእንስሳት እና አግሪቢዝነስ አገልግሎቶች | ASF Agro Industry"}],["$","meta","1",{"name":"description","content":"የታቀደ ለውጭ ገበያ ደረጃ የእንስሳት እርድ ቤት እና የእንስሳት መድሃኒት እና መገልገያ አቅርቦት።"}],["$","link","2",{"rel":"canonical","href":"https://asfagro.com/am/products/livestock-agribusiness-services"}],["$","link","3",{"rel":"alternate","hrefLang":"en","href":"https://asfagro.com/en/products/livestock-agribusiness-services"}],["$","link","4",{"rel":"alternate","hrefLang":"am","href":"https://asfagro.com/am/products/livestock-agribusiness-services"}],["$","link","5",{"rel":"alternate","hrefLang":"om","href":"https://asfagro.com/om/products/livestock-agribusiness-services"}],["$","link","6",{"rel":"alternate","hrefLang":"x-default","href":"https://asfagro.com/en/products/livestock-agribusiness-services"}],["$","meta","7",{"property":"og:title","content":"የእንስሳት እና አግሪቢዝነስ አገልግሎቶች"}],["$","meta","8",{"property":"og:description","content":"የታቀደ ለውጭ ገበያ ደረጃ የእንስሳት እርድ ቤት እና የእንስሳት መድሃኒት እና መገልገያ አቅርቦት።"}],["$","meta","9",{"property":"og:url","content":"https://asfagro.com/am/products/livestock-agribusiness-services"}],["$","meta","10",{"property":"og:site_name","content":"ASF Agro Industry"}],["$","meta","11",{"property":"og:locale","content":"am"}],"$La","$Lb","$Lc","$Ld","$Le","$Lf","$L10","$L11"]}]}]}],"$L12"]}],"isPartial":"$@13","staleTime":"$7","varyParams":null},{"rsc":"$L14","isPartial":"$@15","staleTime":"$7","varyParams":"$16"},{"rsc":"$L17","isPartial":"$@18","staleTime":"$7","varyParams":"$16"}],"isUpgradeableISRFallback":false,"a":"$@19","rootVaryParams":null,"needsRuntimeRequest":"$@1a"}
1b:I[27201,["/_next/static/chunks/3fntmmi971322.js"],"IconMark"]
1c:I[39756,["/_next/static/chunks/3fntmmi971322.js"],"default"]
1d:I[37457,["/_next/static/chunks/3fntmmi971322.js"],"default"]
5:null
a:["$","meta","12",{"property":"og:image","content":"https://asfagro.com/asf-logo.png"}]
b:["$","meta","13",{"property":"og:type","content":"website"}]
c:["$","meta","14",{"name":"twitter:card","content":"summary_large_image"}]
d:["$","meta","15",{"name":"twitter:title","content":"የእንስሳት እና አግሪቢዝነስ አገልግሎቶች"}]
e:["$","meta","16",{"name":"twitter:description","content":"የታቀደ ለውጭ ገበያ ደረጃ የእንስሳት እርድ ቤት እና የእንስሳት መድሃኒት እና መገልገያ አቅርቦት።"}]
f:["$","meta","17",{"name":"twitter:image","content":"https://asfagro.com/asf-logo.png"}]
10:["$","link","18",{"rel":"icon","href":"/asf-logo.png"}]
11:["$","$L1b","19",{}]
12:["$","meta",null,{"name":"next-size-adjust","content":""}]
14:["$","$1","c",{"children":[null,["$","$L1c",null,{"parallelRouterKey":"children","template":["$","$L1d",null,{}]}]]}]
17:["$","$1","c",{"children":[null,["$","$L1c",null,{"parallelRouterKey":"children","template":["$","$L1d",null,{}]}]]}]
1a:true
7:300
7:C
19:0
13:"$undefined"
15:"$undefined"
18:"$undefined"
6:"$undefined"
