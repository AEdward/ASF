1:"$Sreact.fragment"
2:I[77105,["/_next/static/chunks/2dru2glu73-eh.js","/_next/static/chunks/14xmgymk1sega.js"],"default"]
3:I[5500,["/_next/static/chunks/2dru2glu73-eh.js","/_next/static/chunks/14xmgymk1sega.js"],"Image"]
4:I[97367,["/_next/static/chunks/3fntmmi971322.js"],"OutletBoundary"]
5:"$Sreact.suspense"
9:I[97367,["/_next/static/chunks/3fntmmi971322.js"],"ViewportBoundary"]
a:I[97367,["/_next/static/chunks/3fntmmi971322.js"],"MetadataBoundary"]
8:X
1c:X
1c:C
0:{"buildId":"fHhRWd-NoCwSpf___tmoY","data":[{"rsc":["$","$1","c",{"children":[["$","main",null,{"children":[["$","script",null,{"type":"application/ld+json","dangerouslySetInnerHTML":{"__html":"{\"@context\":\"https://schema.org\",\"@type\":\"Product\",\"name\":\"የወተት መኖ\",\"description\":\"የቱሉ ቦሎ የእንስሳት መኖ ምርት ዘርፍ አካል።\",\"url\":\"https://asfagro.com/am/products/dairy-feed\",\"image\":[\"http://localhost:1691/uploads/dairy_feed_49491ef1f0.webp\"],\"brand\":{\"@type\":\"Brand\",\"name\":\"ASF Agro Industry\"}}"}}],["$","script",null,{"type":"application/ld+json","dangerouslySetInnerHTML":{"__html":"{\"@context\":\"https://schema.org\",\"@type\":\"BreadcrumbList\",\"itemListElement\":[{\"@type\":\"ListItem\",\"position\":1,\"name\":\"መነሻ\",\"item\":\"https://asfagro.com/am\"},{\"@type\":\"ListItem\",\"position\":2,\"name\":\"ምርቶች\",\"item\":\"https://asfagro.com/am/products\"},{\"@type\":\"ListItem\",\"position\":3,\"name\":\"የወተት መኖ\",\"item\":\"https://asfagro.com/am/products/dairy-feed\"}]}"}}],["$","section",null,{"className":"bg-[linear-gradient(135deg,#f5fff0,#fffaf0)] py-20","children":["$","div",null,{"className":"mx-auto max-w-5xl px-5 lg:px-8","children":[["$","$L2",null,{"href":"/am/products","localeCookie":{"name":"NEXT_LOCALE","sameSite":"lax"},"className":"text-sm font-bold text-green-700","children":"← ወደ ምርቶች ተመለስ"}],["$","div",null,{"className":"mb-4 flex items-center gap-2 text-xs font-black uppercase tracking-[.15em] text-green-700","children":[["$","span",null,{"className":"h-1 w-7 rounded bg-[#f5a617]"}],"የአሁኑ"]}],["$","h1",null,{"className":"max-w-3xl text-4xl font-black tracking-tight sm:text-5xl","children":"የወተት መኖ"}],["$","p",null,{"className":"mt-6 max-w-2xl text-lg text-slate-600","children":"የቱሉ ቦሎ የእንስሳት መኖ ምርት ዘርፍ አካል።"}]]}]}],["$","section",null,{"className":"py-16","children":["$","div",null,{"className":"mx-auto grid max-w-5xl gap-12 px-5 lg:grid-cols-2 lg:px-8","children":[["$","div",null,{"children":["$","div",null,{"className":"relative aspect-square overflow-hidden rounded-3xl bg-white","children":["$","$L3",null,{"src":"http://localhost:1691/uploads/dairy_feed_49491ef1f0.webp","alt":"የወተት መኖ — የASF አግሮ ኢንዱስትሪ የእንስሳት መኖ ምርት","fill":true,"className":"object-contain p-6"}]}]}],["$","div",null,{"children":[["$","ul",null,{"className":"space-y-3","children":[["$","li","የአሁኑ የተገለጸ አቅም፦ 400 ኩንታል/ቀን",{"className":"flex gap-3 text-slate-700","children":[["$","span",null,{"className":"mt-1 h-2 w-2 shrink-0 rounded-full bg-[#58c900]"}],"የአሁኑ የተገለጸ አቅም፦ 400 ኩንታል/ቀን"]}],["$","li","የ1ኛ ዓመት ዕቅድ፦ 100,000 ኩንታል",{"className":"flex gap-3 text-slate-700","children":[["$","span",null,{"className":"mt-1 h-2 w-2 shrink-0 rounded-full bg-[#58c900]"}],"የ1ኛ ዓመት ዕቅድ፦ 100,000 ኩንታል"]}],["$","li","የ3ኛ ዓመት ዕቅድ፦ 180,000 ኩንታል",{"className":"flex gap-3 text-slate-700","children":[["$","span",null,{"className":"mt-1 h-2 w-2 shrink-0 rounded-full bg-[#58c900]"}],"የ3ኛ ዓመት ዕቅድ፦ 180,000 ኩንታል"]}]]}],"$undefined",["$","div",null,{"className":"mt-10","children":["$","$L2",null,{"href":"/am/contact","localeCookie":"$0:data:0:rsc:props:children:0:props:children:2:props:children:props:children:0:props:localeCookie","className":"inline-flex rounded-xl px-5 py-3 text-sm font-extrabold bg-[#58c900] text-[#092713]","children":"የዋጋ ጥቆማ ይጠይቁ →"}]}]]}]]}]}],false]}],null,["$","$L4",null,{"children":["$","$5",null,{"name":"Next.MetadataOutlet","children":"$@6"}]}]]}],"isPartial":"$@7","staleTime":"$8","varyParams":null},{"rsc":["$","$1","h",{"children":[null,["$","$L9",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$La",null,{"children":["$","$5",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"የወተት መኖ | ASF Agro Industry"}],["$","meta","1",{"name":"description","content":"የቱሉ ቦሎ የእንስሳት መኖ ምርት ዘርፍ አካል።"}],["$","link","2",{"rel":"canonical","href":"https://asfagro.com/am/products/dairy-feed"}],["$","link","3",{"rel":"alternate","hrefLang":"en","href":"https://asfagro.com/en/products/dairy-feed"}],["$","link","4",{"rel":"alternate","hrefLang":"am","href":"https://asfagro.com/am/products/dairy-feed"}],["$","link","5",{"rel":"alternate","hrefLang":"om","href":"https://asfagro.com/om/products/dairy-feed"}],["$","link","6",{"rel":"alternate","hrefLang":"x-default","href":"https://asfagro.com/en/products/dairy-feed"}],"$Lb","$Lc","$Ld","$Le","$Lf","$L10","$L11","$L12","$L13","$L14","$L15","$L16","$L17"]}]}]}],"$L18"]}],"isPartial":"$@19","staleTime":"$8","varyParams":null},{"rsc":"$L1a","isPartial":"$@1b","staleTime":"$8","varyParams":"$1c"},{"rsc":"$L1d","isPartial":"$@1e","staleTime":"$8","varyParams":"$1c"}],"isUpgradeableISRFallback":false,"a":"$@1f","rootVaryParams":null,"needsRuntimeRequest":"$@20"}
21:I[27201,["/_next/static/chunks/3fntmmi971322.js"],"IconMark"]
22:I[39756,["/_next/static/chunks/3fntmmi971322.js"],"default"]
23:I[37457,["/_next/static/chunks/3fntmmi971322.js"],"default"]
6:null
b:["$","meta","7",{"property":"og:title","content":"የወተት መኖ"}]
c:["$","meta","8",{"property":"og:description","content":"የቱሉ ቦሎ የእንስሳት መኖ ምርት ዘርፍ አካል።"}]
d:["$","meta","9",{"property":"og:url","content":"https://asfagro.com/am/products/dairy-feed"}]
e:["$","meta","10",{"property":"og:site_name","content":"ASF Agro Industry"}]
f:["$","meta","11",{"property":"og:locale","content":"am"}]
10:["$","meta","12",{"property":"og:image","content":"http://localhost:1691/uploads/dairy_feed_49491ef1f0.webp"}]
11:["$","meta","13",{"property":"og:type","content":"website"}]
12:["$","meta","14",{"name":"twitter:card","content":"summary_large_image"}]
13:["$","meta","15",{"name":"twitter:title","content":"የወተት መኖ"}]
14:["$","meta","16",{"name":"twitter:description","content":"የቱሉ ቦሎ የእንስሳት መኖ ምርት ዘርፍ አካል።"}]
15:["$","meta","17",{"name":"twitter:image","content":"http://localhost:1691/uploads/dairy_feed_49491ef1f0.webp"}]
16:["$","link","18",{"rel":"icon","href":"/asf-logo.png"}]
17:["$","$L21","19",{}]
18:["$","meta",null,{"name":"next-size-adjust","content":""}]
1a:["$","$1","c",{"children":[null,["$","$L22",null,{"parallelRouterKey":"children","template":["$","$L23",null,{}]}]]}]
1d:["$","$1","c",{"children":[null,["$","$L22",null,{"parallelRouterKey":"children","template":["$","$L23",null,{}]}]]}]
20:true
8:300
8:C
1f:0
19:"$undefined"
1b:"$undefined"
1e:"$undefined"
7:"$undefined"
