1:"$Sreact.fragment"
2:I[77105,["/_next/static/chunks/2dru2glu73-eh.js","/_next/static/chunks/14xmgymk1sega.js"],"default"]
3:I[97367,["/_next/static/chunks/3fntmmi971322.js"],"OutletBoundary"]
4:"$Sreact.suspense"
8:I[97367,["/_next/static/chunks/3fntmmi971322.js"],"ViewportBoundary"]
9:I[97367,["/_next/static/chunks/3fntmmi971322.js"],"MetadataBoundary"]
7:X
18:X
18:C
0:{"buildId":"fHhRWd-NoCwSpf___tmoY","data":[{"rsc":["$","$1","c",{"children":[["$","main",null,{"children":[["$","script",null,{"type":"application/ld+json","dangerouslySetInnerHTML":{"__html":"{\"@context\":\"https://schema.org\",\"@type\":\"Article\",\"headline\":\"አርሶ አደሮችን፣ ገበያዎችን እና አግሮ ማቀነባበርን ማገናኘት\",\"description\":\"የASF የእንስሳት መኖ ወደ እንስሳት አርሶ አደሮችና ድርጅቶች የሚደርሰው በአርሶ አደር ማህበራት፣ ኅብረት ስራ ማህበራት፣ አከፋፋዮች እና ችርቻሮ ሻጮች የስርጭት መረብ እንዲሁም በቀጥታ ሽያጭ በኩል ነው።\",\"url\":\"https://asfagro.com/am/blog/connecting-farmers-markets-agro-processing\",\"publisher\":{\"@type\":\"Organization\",\"name\":\"ASF Agro Industry\",\"logo\":{\"@type\":\"ImageObject\",\"url\":\"https://asfagro.com/asf-logo.png\"}}}"}}],["$","script",null,{"type":"application/ld+json","dangerouslySetInnerHTML":{"__html":"{\"@context\":\"https://schema.org\",\"@type\":\"BreadcrumbList\",\"itemListElement\":[{\"@type\":\"ListItem\",\"position\":1,\"name\":\"መነሻ\",\"item\":\"https://asfagro.com/am\"},{\"@type\":\"ListItem\",\"position\":2,\"name\":\"ዜና እና ብሎግ\",\"item\":\"https://asfagro.com/am/blog\"},{\"@type\":\"ListItem\",\"position\":3,\"name\":\"አርሶ አደሮችን፣ ገበያዎችን እና አግሮ ማቀነባበርን ማገናኘት\",\"item\":\"https://asfagro.com/am/blog/connecting-farmers-markets-agro-processing\"}]}"}}],["$","section",null,{"className":"bg-[linear-gradient(135deg,#f5fff0,#fffaf0)] py-20","children":["$","div",null,{"className":"mx-auto max-w-4xl px-5 lg:px-8","children":[["$","$L2",null,{"href":"/am/blog","localeCookie":{"name":"NEXT_LOCALE","sameSite":"lax"},"className":"text-sm font-bold text-green-700","children":"← ወደ ዜና እና ብሎግ ተመለስ"}],["$","div",null,{"className":"mb-4 flex items-center gap-2 text-xs font-black uppercase tracking-[.15em] text-green-700","children":[["$","span",null,{"className":"h-1 w-7 rounded bg-[#f5a617]"}],"ግብርና"]}],["$","h1",null,{"className":"max-w-3xl text-4xl font-black tracking-tight sm:text-5xl","children":"አርሶ አደሮችን፣ ገበያዎችን እና አግሮ ማቀነባበርን ማገናኘት"}]]}]}],"$undefined",["$","section",null,{"className":"py-16","children":["$","div",null,{"className":"mx-auto max-w-4xl px-5 lg:px-8","children":["$","div",null,{"className":"whitespace-pre-line text-lg leading-8 text-slate-700","children":"የASF የእንስሳት መኖ ወደ እንስሳት አርሶ አደሮችና ድርጅቶች የሚደርሰው በአርሶ አደር ማህበራት፣ ኅብረት ስራ ማህበራት፣ አከፋፋዮች እና ችርቻሮ ሻጮች የስርጭት መረብ እንዲሁም በቀጥታ ሽያጭ በኩል ነው።"}]}]}]]}],null,["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":"$@6","staleTime":"$7","varyParams":null},{"rsc":["$","$1","h",{"children":[null,["$","$L8",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L9",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"አርሶ አደሮችን፣ ገበያዎችን እና አግሮ ማቀነባበርን ማገናኘት | ASF Agro Industry"}],["$","meta","1",{"name":"description","content":"የASF የእንስሳት መኖ ወደ እንስሳት አርሶ አደሮችና ድርጅቶች የሚደርሰው በአርሶ አደር ማህበራት፣ ኅብረት ስራ ማህበራት፣ አከፋፋዮች እና ችርቻሮ ሻጮች የስርጭት መረብ እንዲሁም በቀጥታ ሽያጭ በኩል ነው።"}],["$","link","2",{"rel":"canonical","href":"https://asfagro.com/am/blog/connecting-farmers-markets-agro-processing"}],["$","link","3",{"rel":"alternate","hrefLang":"en","href":"https://asfagro.com/en/blog/connecting-farmers-markets-agro-processing"}],["$","link","4",{"rel":"alternate","hrefLang":"am","href":"https://asfagro.com/am/blog/connecting-farmers-markets-agro-processing"}],["$","link","5",{"rel":"alternate","hrefLang":"om","href":"https://asfagro.com/om/blog/connecting-farmers-markets-agro-processing"}],["$","link","6",{"rel":"alternate","hrefLang":"x-default","href":"https://asfagro.com/en/blog/connecting-farmers-markets-agro-processing"}],["$","meta","7",{"property":"og:title","content":"አርሶ አደሮችን፣ ገበያዎችን እና አግሮ ማቀነባበርን ማገናኘት"}],["$","meta","8",{"property":"og:description","content":"የASF የእንስሳት መኖ ወደ እንስሳት አርሶ አደሮችና ድርጅቶች የሚደርሰው በአርሶ አደር ማህበራት፣ ኅብረት ስራ ማህበራት፣ አከፋፋዮች እና ችርቻሮ ሻጮች የስርጭት መረብ እንዲሁም በቀጥታ ሽያጭ በኩል ነው።"}],["$","meta","9",{"property":"og:url","content":"https://asfagro.com/am/blog/connecting-farmers-markets-agro-processing"}],"$La","$Lb","$Lc","$Ld","$Le","$Lf","$L10","$L11","$L12","$L13"]}]}]}],"$L14"]}],"isPartial":"$@15","staleTime":"$7","varyParams":null},{"rsc":"$L16","isPartial":"$@17","staleTime":"$7","varyParams":"$18"},{"rsc":"$L19","isPartial":"$@1a","staleTime":"$7","varyParams":"$18"}],"isUpgradeableISRFallback":false,"a":"$@1b","rootVaryParams":null,"needsRuntimeRequest":"$@1c"}
1d:I[27201,["/_next/static/chunks/3fntmmi971322.js"],"IconMark"]
1e:I[39756,["/_next/static/chunks/3fntmmi971322.js"],"default"]
1f:I[37457,["/_next/static/chunks/3fntmmi971322.js"],"default"]
5:null
a:["$","meta","10",{"property":"og:site_name","content":"ASF Agro Industry"}]
b:["$","meta","11",{"property":"og:locale","content":"am"}]
c:["$","meta","12",{"property":"og:image","content":"https://asfagro.com/asf-logo.png"}]
d:["$","meta","13",{"property":"og:type","content":"website"}]
e:["$","meta","14",{"name":"twitter:card","content":"summary_large_image"}]
f:["$","meta","15",{"name":"twitter:title","content":"አርሶ አደሮችን፣ ገበያዎችን እና አግሮ ማቀነባበርን ማገናኘት"}]
10:["$","meta","16",{"name":"twitter:description","content":"የASF የእንስሳት መኖ ወደ እንስሳት አርሶ አደሮችና ድርጅቶች የሚደርሰው በአርሶ አደር ማህበራት፣ ኅብረት ስራ ማህበራት፣ አከፋፋዮች እና ችርቻሮ ሻጮች የስርጭት መረብ እንዲሁም በቀጥታ ሽያጭ በኩል ነው።"}]
11:["$","meta","17",{"name":"twitter:image","content":"https://asfagro.com/asf-logo.png"}]
12:["$","link","18",{"rel":"icon","href":"/asf-logo.png"}]
13:["$","$L1d","19",{}]
14:["$","meta",null,{"name":"next-size-adjust","content":""}]
16:["$","$1","c",{"children":[null,["$","$L1e",null,{"parallelRouterKey":"children","template":["$","$L1f",null,{}]}]]}]
19:["$","$1","c",{"children":[null,["$","$L1e",null,{"parallelRouterKey":"children","template":["$","$L1f",null,{}]}]]}]
1c:true
7:300
7:C
1b:0
15:"$undefined"
17:"$undefined"
1a:"$undefined"
6:"$undefined"
