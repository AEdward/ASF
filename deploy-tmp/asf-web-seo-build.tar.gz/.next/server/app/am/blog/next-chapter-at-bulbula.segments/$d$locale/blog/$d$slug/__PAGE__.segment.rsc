1:"$Sreact.fragment"
2:I[77105,["/_next/static/chunks/2dru2glu73-eh.js","/_next/static/chunks/14xmgymk1sega.js"],"default"]
3:I[97367,["/_next/static/chunks/3fntmmi971322.js"],"OutletBoundary"]
4:"$Sreact.suspense"
8:I[97367,["/_next/static/chunks/3fntmmi971322.js"],"ViewportBoundary"]
9:I[97367,["/_next/static/chunks/3fntmmi971322.js"],"MetadataBoundary"]
7:X
17:X
17:C
0:{"buildId":"fHhRWd-NoCwSpf___tmoY","data":[{"rsc":["$","$1","c",{"children":[["$","main",null,{"children":[["$","script",null,{"type":"application/ld+json","dangerouslySetInnerHTML":{"__html":"{\"@context\":\"https://schema.org\",\"@type\":\"Article\",\"headline\":\"የASF ቀጣይ ምዕራፍ በቡልቡላ የተቀናጀ አግሮ ኢንዱስትሪ ፓርክ\",\"description\":\"በየካቲት 2023 ASF ከቡልቡላ የተቀናጀ አግሮ ኢንዱስትሪ ፓርክ ጋር በ271 ሄክታር ቦታ ላይ የኢንቨስትመንት ስምምነት ፈርሟል፣ ከአዲስ አበባ 160 ኪ.ሜ ደቡብ የሚገኝ፣ ለኩባንያው ቀጣይ የእድገት ምዕራፍ መሠረት በመጣል።\",\"url\":\"https://asfagro.com/am/blog/next-chapter-at-bulbula\",\"publisher\":{\"@type\":\"Organization\",\"name\":\"ASF Agro Industry\",\"logo\":{\"@type\":\"ImageObject\",\"url\":\"https://asfagro.com/asf-logo.png\"}}}"}}],["$","script",null,{"type":"application/ld+json","dangerouslySetInnerHTML":{"__html":"{\"@context\":\"https://schema.org\",\"@type\":\"BreadcrumbList\",\"itemListElement\":[{\"@type\":\"ListItem\",\"position\":1,\"name\":\"መነሻ\",\"item\":\"https://asfagro.com/am\"},{\"@type\":\"ListItem\",\"position\":2,\"name\":\"ዜና እና ብሎግ\",\"item\":\"https://asfagro.com/am/blog\"},{\"@type\":\"ListItem\",\"position\":3,\"name\":\"የASF ቀጣይ ምዕራፍ በቡልቡላ የተቀናጀ አግሮ ኢንዱስትሪ ፓርክ\",\"item\":\"https://asfagro.com/am/blog/next-chapter-at-bulbula\"}]}"}}],["$","section",null,{"className":"bg-[linear-gradient(135deg,#f5fff0,#fffaf0)] py-20","children":["$","div",null,{"className":"mx-auto max-w-4xl px-5 lg:px-8","children":[["$","$L2",null,{"href":"/am/blog","localeCookie":{"name":"NEXT_LOCALE","sameSite":"lax"},"className":"text-sm font-bold text-green-700","children":"← ወደ ዜና እና ብሎግ ተመለስ"}],["$","div",null,{"className":"mb-4 flex items-center gap-2 text-xs font-black uppercase tracking-[.15em] text-green-700","children":[["$","span",null,{"className":"h-1 w-7 rounded bg-[#f5a617]"}],"መስፋፋት"]}],["$","h1",null,{"className":"max-w-3xl text-4xl font-black tracking-tight sm:text-5xl","children":"የASF ቀጣይ ምዕራፍ በቡልቡላ የተቀናጀ አግሮ ኢንዱስትሪ ፓርክ"}]]}]}],"$undefined",["$","section",null,{"className":"py-16","children":["$","div",null,{"className":"mx-auto max-w-4xl px-5 lg:px-8","children":["$","div",null,{"className":"whitespace-pre-line text-lg leading-8 text-slate-700","children":"በየካቲት 2023 ASF ከቡልቡላ የተቀናጀ አግሮ ኢንዱስትሪ ፓርክ ጋር በ271 ሄክታር ቦታ ላይ የኢንቨስትመንት ስምምነት ፈርሟል፣ ከአዲስ አበባ 160 ኪ.ሜ ደቡብ የሚገኝ፣ ለኩባንያው ቀጣይ የእድገት ምዕራፍ መሠረት በመጣል።"}]}]}]]}],null,["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":"$@6","staleTime":"$7","varyParams":null},{"rsc":["$","$1","h",{"children":[null,["$","$L8",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L9",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"የASF ቀጣይ ምዕራፍ በቡልቡላ የተቀናጀ አግሮ ኢንዱስትሪ ፓርክ | ASF Agro Industry"}],["$","meta","1",{"name":"description","content":"በየካቲት 2023 ASF ከቡልቡላ የተቀናጀ አግሮ ኢንዱስትሪ ፓርክ ጋር በ271 ሄክታር ቦታ ላይ የኢንቨስትመንት ስምምነት ፈርሟል፣ ከአዲስ አበባ 160 ኪ.ሜ ደቡብ የሚገኝ፣ ለኩባንያው ቀጣይ የእድገት ምዕራፍ መሠረት በመጣል።"}],["$","link","2",{"rel":"canonical","href":"https://asfagro.com/am/blog/next-chapter-at-bulbula"}],["$","link","3",{"rel":"alternate","hrefLang":"en","href":"https://asfagro.com/en/blog/next-chapter-at-bulbula"}],["$","link","4",{"rel":"alternate","hrefLang":"am","href":"https://asfagro.com/am/blog/next-chapter-at-bulbula"}],["$","link","5",{"rel":"alternate","hrefLang":"om","href":"https://asfagro.com/om/blog/next-chapter-at-bulbula"}],["$","link","6",{"rel":"alternate","hrefLang":"x-default","href":"https://asfagro.com/en/blog/next-chapter-at-bulbula"}],["$","meta","7",{"property":"og:title","content":"የASF ቀጣይ ምዕራፍ በቡልቡላ የተቀናጀ አግሮ ኢንዱስትሪ ፓርክ"}],["$","meta","8",{"property":"og:description","content":"በየካቲት 2023 ASF ከቡልቡላ የተቀናጀ አግሮ ኢንዱስትሪ ፓርክ ጋር በ271 ሄክታር ቦታ ላይ የኢንቨስትመንት ስምምነት ፈርሟል፣ ከአዲስ አበባ 160 ኪ.ሜ ደቡብ የሚገኝ፣ ለኩባንያው ቀጣይ የእድገት ምዕራፍ መሠረት በመጣል።"}],["$","meta","9",{"property":"og:url","content":"https://asfagro.com/am/blog/next-chapter-at-bulbula"}],["$","meta","10",{"property":"og:site_name","content":"ASF Agro Industry"}],"$La","$Lb","$Lc","$Ld","$Le","$Lf","$L10","$L11","$L12"]}]}]}],"$L13"]}],"isPartial":"$@14","staleTime":"$7","varyParams":null},{"rsc":"$L15","isPartial":"$@16","staleTime":"$7","varyParams":"$17"},{"rsc":"$L18","isPartial":"$@19","staleTime":"$7","varyParams":"$17"}],"isUpgradeableISRFallback":false,"a":"$@1a","rootVaryParams":null,"needsRuntimeRequest":"$@1b"}
1c:I[27201,["/_next/static/chunks/3fntmmi971322.js"],"IconMark"]
1d:I[39756,["/_next/static/chunks/3fntmmi971322.js"],"default"]
1e:I[37457,["/_next/static/chunks/3fntmmi971322.js"],"default"]
5:null
a:["$","meta","11",{"property":"og:locale","content":"am"}]
b:["$","meta","12",{"property":"og:image","content":"https://asfagro.com/asf-logo.png"}]
c:["$","meta","13",{"property":"og:type","content":"website"}]
d:["$","meta","14",{"name":"twitter:card","content":"summary_large_image"}]
e:["$","meta","15",{"name":"twitter:title","content":"የASF ቀጣይ ምዕራፍ በቡልቡላ የተቀናጀ አግሮ ኢንዱስትሪ ፓርክ"}]
f:["$","meta","16",{"name":"twitter:description","content":"በየካቲት 2023 ASF ከቡልቡላ የተቀናጀ አግሮ ኢንዱስትሪ ፓርክ ጋር በ271 ሄክታር ቦታ ላይ የኢንቨስትመንት ስምምነት ፈርሟል፣ ከአዲስ አበባ 160 ኪ.ሜ ደቡብ የሚገኝ፣ ለኩባንያው ቀጣይ የእድገት ምዕራፍ መሠረት በመጣል።"}]
10:["$","meta","17",{"name":"twitter:image","content":"https://asfagro.com/asf-logo.png"}]
11:["$","link","18",{"rel":"icon","href":"/asf-logo.png"}]
12:["$","$L1c","19",{}]
13:["$","meta",null,{"name":"next-size-adjust","content":""}]
15:["$","$1","c",{"children":[null,["$","$L1d",null,{"parallelRouterKey":"children","template":["$","$L1e",null,{}]}]]}]
18:["$","$1","c",{"children":[null,["$","$L1d",null,{"parallelRouterKey":"children","template":["$","$L1e",null,{}]}]]}]
1b:true
7:300
7:C
1a:0
14:"$undefined"
16:"$undefined"
19:"$undefined"
6:"$undefined"
