1:"$Sreact.fragment"
2:I[19049,["/_next/static/chunks/2dru2glu73-eh.js","/_next/static/chunks/14xmgymk1sega.js","/_next/static/chunks/35kf7xylhynjn.js"],"ContactForm"]
3:I[97367,["/_next/static/chunks/3fntmmi971322.js"],"OutletBoundary"]
4:"$Sreact.suspense"
8:I[97367,["/_next/static/chunks/3fntmmi971322.js"],"ViewportBoundary"]
9:I[97367,["/_next/static/chunks/3fntmmi971322.js"],"MetadataBoundary"]
7:X
20:X
20:C
0:{"buildId":"fHhRWd-NoCwSpf___tmoY","data":[{"rsc":["$","$1","c",{"children":[["$","main",null,{"children":[["$","script",null,{"type":"application/ld+json","dangerouslySetInnerHTML":{"__html":"{\"@context\":\"https://schema.org\",\"@type\":\"BreadcrumbList\",\"itemListElement\":[{\"@type\":\"ListItem\",\"position\":1,\"name\":\"Fuula Jalqabaa\",\"item\":\"https://asfagro.com/om\"},{\"@type\":\"ListItem\",\"position\":2,\"name\":\"Nu Qunnami\",\"item\":\"https://asfagro.com/om/contact\"}]}"}}],["$","section",null,{"className":"bg-[linear-gradient(135deg,#f5fff0,#fffaf0)] py-20","children":["$","div",null,{"className":"mx-auto max-w-7xl px-5 lg:px-8","children":[["$","div",null,{"className":"mb-4 flex items-center gap-2 text-xs font-black uppercase tracking-[.15em] text-green-700","children":[["$","span",null,{"className":"h-1 w-7 rounded bg-[#f5a617]"}],"ASF Qunnami"]}],["$","h1",null,{"className":"max-w-4xl text-5xl font-black tracking-tight sm:text-6xl","children":"Fuulduraa qonnaa waliin haa ijaarru."}],["$","p",null,{"className":"mt-6 max-w-2xl text-lg text-slate-600","children":"Michoomaa, dhiyeessii nyaataa, guddina daldalaa fi gaaffiiwwan biroof, garee ASF quunnamaa."}]]}]}],["$","section",null,{"className":"py-24","children":[["$","div",null,{"className":"mx-auto grid max-w-7xl gap-6 px-5 lg:grid-cols-2 lg:px-8","children":[["$","div",null,{"className":"rounded-3xl border p-8","children":[["$","div",null,{"className":"mb-4 flex items-center gap-2 text-xs font-black uppercase tracking-[.15em] text-green-700","children":[["$","span",null,{"className":"h-1 w-7 rounded bg-[#f5a617]"}],"Odeeffannoo Dhaabbataa"]}],["$","h2",null,{"className":"text-3xl font-black","children":"Garee keenya qunnamaa."}],["$","div",null,{"className":"mt-7 space-y-3","children":[["$","div","Waajjira Muummee",{"className":"rounded-2xl bg-slate-50 p-4","children":[["$","b",null,{"className":"block text-xs uppercase tracking-widest text-green-700","children":"Waajjira Muummee"}],["$","span",null,{"children":"Akaki Qaallittii Aanaa 05, naannoo Qaallittii Maasaltanyaa, Finfinnee, Itoophiyaa"}]]}],["$","div","Warshaa Hojiirra Jiru",{"className":"rounded-2xl bg-slate-50 p-4","children":[["$","b",null,{"className":"block text-xs uppercase tracking-widest text-green-700","children":"Warshaa Hojiirra Jiru"}],["$","span",null,{"children":"Warshaa Hojiirra Jiru: Magaalaa Tuulluu Boolloo, Godina Shawaa Kibba Lixaa, Naannoo Oromiyaa. Buufata Kuusaa: Waleetee, Magaalaa Sheegar."}]]}],["$","div","Bakka Babal'ina",{"className":"rounded-2xl bg-slate-50 p-4","children":[["$","b",null,{"className":"block text-xs uppercase tracking-widest text-green-700","children":"Bakka Babal'ina"}],["$","span",null,{"children":"Bakka Babal'ina (adeemsa irra jiru): Paarkii Warshaalee Qonnaa Walitti Qindaa'e Bulbulaa, kiiloomeetira 160 kibba Finfinnee, naannoo Magaalaa Zeeway karaa gara Hawaasaa."}]]}],["$","div","Bilbila",{"className":"rounded-2xl bg-slate-50 p-4","children":[["$","b",null,{"className":"block text-xs uppercase tracking-widest text-green-700","children":"Bilbila"}],["$","span",null,{"children":"0976177236 · 0911540903 / 0911200732"}]]}],["$","div","Imeelii",{"className":"rounded-2xl bg-slate-50 p-4","children":[["$","b",null,{"className":"block text-xs uppercase tracking-widest text-green-700","children":"Imeelii"}],["$","span",null,{"children":"merihun@asfagro.com · argaw@asfagro.com"}]]}]]}]]}],["$","$L2",null,{}]]}],null]}]]}],[["$","script","script-0",{"src":"/_next/static/chunks/35kf7xylhynjn.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":"$@6","staleTime":"$7","varyParams":null},{"rsc":["$","$1","h",{"children":[null,["$","$L8",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L9",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"Nu Qunnami | ASF Agro Industry"}],["$","meta","1",{"name":"description","content":"Michoomaa fi gaaffiif garee ASF Agro Industry quunnamaa."}],"$La","$Lb","$Lc","$Ld","$Le","$Lf","$L10","$L11","$L12","$L13","$L14","$L15","$L16","$L17","$L18","$L19","$L1a","$L1b"]}]}]}],"$L1c"]}],"isPartial":"$@1d","staleTime":"$7","varyParams":null},{"rsc":"$L1e","isPartial":"$@1f","staleTime":"$7","varyParams":"$20"}],"isUpgradeableISRFallback":false,"a":"$@21","rootVaryParams":null,"needsRuntimeRequest":"$@22"}
23:I[27201,["/_next/static/chunks/3fntmmi971322.js"],"IconMark"]
24:I[39756,["/_next/static/chunks/3fntmmi971322.js"],"default"]
25:I[37457,["/_next/static/chunks/3fntmmi971322.js"],"default"]
5:null
a:["$","link","2",{"rel":"canonical","href":"https://asfagro.com/om/contact"}]
b:["$","link","3",{"rel":"alternate","hrefLang":"en","href":"https://asfagro.com/en/contact"}]
c:["$","link","4",{"rel":"alternate","hrefLang":"am","href":"https://asfagro.com/am/contact"}]
d:["$","link","5",{"rel":"alternate","hrefLang":"om","href":"https://asfagro.com/om/contact"}]
e:["$","link","6",{"rel":"alternate","hrefLang":"x-default","href":"https://asfagro.com/en/contact"}]
f:["$","meta","7",{"property":"og:title","content":"Nu Qunnami"}]
10:["$","meta","8",{"property":"og:description","content":"Michoomaa fi gaaffiif garee ASF Agro Industry quunnamaa."}]
11:["$","meta","9",{"property":"og:url","content":"https://asfagro.com/om/contact"}]
12:["$","meta","10",{"property":"og:site_name","content":"ASF Agro Industry"}]
13:["$","meta","11",{"property":"og:locale","content":"om"}]
14:["$","meta","12",{"property":"og:image","content":"https://asfagro.com/asf-logo.png"}]
15:["$","meta","13",{"property":"og:type","content":"website"}]
16:["$","meta","14",{"name":"twitter:card","content":"summary_large_image"}]
17:["$","meta","15",{"name":"twitter:title","content":"Nu Qunnami"}]
18:["$","meta","16",{"name":"twitter:description","content":"Michoomaa fi gaaffiif garee ASF Agro Industry quunnamaa."}]
19:["$","meta","17",{"name":"twitter:image","content":"https://asfagro.com/asf-logo.png"}]
1a:["$","link","18",{"rel":"icon","href":"/asf-logo.png"}]
1b:["$","$L23","19",{}]
1c:["$","meta",null,{"name":"next-size-adjust","content":""}]
1e:["$","$1","c",{"children":[null,["$","$L24",null,{"parallelRouterKey":"children","template":["$","$L25",null,{}]}]]}]
22:true
7:300
7:C
21:0
1d:"$undefined"
1f:"$undefined"
6:"$undefined"
