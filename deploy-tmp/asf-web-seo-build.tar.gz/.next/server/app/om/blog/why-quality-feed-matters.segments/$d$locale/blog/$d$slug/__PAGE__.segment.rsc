1:"$Sreact.fragment"
2:I[77105,["/_next/static/chunks/2dru2glu73-eh.js","/_next/static/chunks/14xmgymk1sega.js"],"default"]
3:I[97367,["/_next/static/chunks/3fntmmi971322.js"],"OutletBoundary"]
4:"$Sreact.suspense"
8:I[97367,["/_next/static/chunks/3fntmmi971322.js"],"ViewportBoundary"]
9:I[97367,["/_next/static/chunks/3fntmmi971322.js"],"MetadataBoundary"]
7:X
1b:X
1b:C
0:{"buildId":"fHhRWd-NoCwSpf___tmoY","data":[{"rsc":["$","$1","c",{"children":[["$","main",null,{"children":[["$","script",null,{"type":"application/ld+json","dangerouslySetInnerHTML":{"__html":"{\"@context\":\"https://schema.org\",\"@type\":\"Article\",\"headline\":\"Nyaatni Qulqullina Qabu Sarara Gatii Beeladaa Keessatti Maaliif Barbaachisaa Ta'e\",\"description\":\"Toʼannoonni qulqullinaa fi ogeeyyiin laaboraatorii ASF meeshaa jalqabaa walitti qabuu irraa hanga nyaata xumurame qonnaan bultoota Itoophiyaa gaʼutti, sadarkaa hunda irratti sadarkaa oomishaa deeggaru.\",\"url\":\"https://asfagro.com/om/blog/why-quality-feed-matters\",\"publisher\":{\"@type\":\"Organization\",\"name\":\"ASF Agro Industry\",\"logo\":{\"@type\":\"ImageObject\",\"url\":\"https://asfagro.com/asf-logo.png\"}}}"}}],["$","script",null,{"type":"application/ld+json","dangerouslySetInnerHTML":{"__html":"{\"@context\":\"https://schema.org\",\"@type\":\"BreadcrumbList\",\"itemListElement\":[{\"@type\":\"ListItem\",\"position\":1,\"name\":\"Fuula Jalqabaa\",\"item\":\"https://asfagro.com/om\"},{\"@type\":\"ListItem\",\"position\":2,\"name\":\"Oduu fi Barreeffama\",\"item\":\"https://asfagro.com/om/blog\"},{\"@type\":\"ListItem\",\"position\":3,\"name\":\"Nyaatni Qulqullina Qabu Sarara Gatii Beeladaa Keessatti Maaliif Barbaachisaa Ta'e\",\"item\":\"https://asfagro.com/om/blog/why-quality-feed-matters\"}]}"}}],["$","section",null,{"className":"bg-[linear-gradient(135deg,#f5fff0,#fffaf0)] py-20","children":["$","div",null,{"className":"mx-auto max-w-4xl px-5 lg:px-8","children":[["$","$L2",null,{"href":"/om/blog","localeCookie":{"name":"NEXT_LOCALE","sameSite":"lax"},"className":"text-sm font-bold text-green-700","children":"← Gara Oduu fi Barreeffama deebi'i"}],["$","div",null,{"className":"mb-4 flex items-center gap-2 text-xs font-black uppercase tracking-[.15em] text-green-700","children":[["$","span",null,{"className":"h-1 w-7 rounded bg-[#f5a617]"}],"Nyaataa fi Nyaata Madaalawaa"]}],["$","h1",null,{"className":"max-w-3xl text-4xl font-black tracking-tight sm:text-5xl","children":"Nyaatni Qulqullina Qabu Sarara Gatii Beeladaa Keessatti Maaliif Barbaachisaa Ta'e"}]]}]}],"$undefined",["$","section",null,{"className":"py-16","children":["$","div",null,{"className":"mx-auto max-w-4xl px-5 lg:px-8","children":["$","div",null,{"className":"whitespace-pre-line text-lg leading-8 text-slate-700","children":"Toʼannoonni qulqullinaa fi ogeeyyiin laaboraatorii ASF meeshaa jalqabaa walitti qabuu irraa hanga nyaata xumurame qonnaan bultoota Itoophiyaa gaʼutti, sadarkaa hunda irratti sadarkaa oomishaa deeggaru."}]}]}]]}],null,["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":"$@6","staleTime":"$7","varyParams":null},{"rsc":["$","$1","h",{"children":[null,["$","$L8",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L9",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"Nyaatni Qulqullina Qabu Sarara Gatii Beeladaa Keessatti Maaliif Barbaachisaa Ta'e | ASF Agro Industry"}],["$","meta","1",{"name":"description","content":"Toʼannoonni qulqullinaa fi ogeeyyiin laaboraatorii ASF meeshaa jalqabaa walitti qabuu irraa hanga nyaata xumurame qonnaan bultoota Itoophiyaa gaʼutti, sadarkaa hunda irratti sadarkaa oomishaa deeggaru."}],["$","link","2",{"rel":"canonical","href":"https://asfagro.com/om/blog/why-quality-feed-matters"}],["$","link","3",{"rel":"alternate","hrefLang":"en","href":"https://asfagro.com/en/blog/why-quality-feed-matters"}],["$","link","4",{"rel":"alternate","hrefLang":"am","href":"https://asfagro.com/am/blog/why-quality-feed-matters"}],["$","link","5",{"rel":"alternate","hrefLang":"om","href":"https://asfagro.com/om/blog/why-quality-feed-matters"}],["$","link","6",{"rel":"alternate","hrefLang":"x-default","href":"https://asfagro.com/en/blog/why-quality-feed-matters"}],"$La","$Lb","$Lc","$Ld","$Le","$Lf","$L10","$L11","$L12","$L13","$L14","$L15","$L16"]}]}]}],"$L17"]}],"isPartial":"$@18","staleTime":"$7","varyParams":null},{"rsc":"$L19","isPartial":"$@1a","staleTime":"$7","varyParams":"$1b"},{"rsc":"$L1c","isPartial":"$@1d","staleTime":"$7","varyParams":"$1b"}],"isUpgradeableISRFallback":false,"a":"$@1e","rootVaryParams":null,"needsRuntimeRequest":"$@1f"}
20:I[27201,["/_next/static/chunks/3fntmmi971322.js"],"IconMark"]
21:I[39756,["/_next/static/chunks/3fntmmi971322.js"],"default"]
22:I[37457,["/_next/static/chunks/3fntmmi971322.js"],"default"]
5:null
a:["$","meta","7",{"property":"og:title","content":"Nyaatni Qulqullina Qabu Sarara Gatii Beeladaa Keessatti Maaliif Barbaachisaa Ta'e"}]
b:["$","meta","8",{"property":"og:description","content":"Toʼannoonni qulqullinaa fi ogeeyyiin laaboraatorii ASF meeshaa jalqabaa walitti qabuu irraa hanga nyaata xumurame qonnaan bultoota Itoophiyaa gaʼutti, sadarkaa hunda irratti sadarkaa oomishaa deeggaru."}]
c:["$","meta","9",{"property":"og:url","content":"https://asfagro.com/om/blog/why-quality-feed-matters"}]
d:["$","meta","10",{"property":"og:site_name","content":"ASF Agro Industry"}]
e:["$","meta","11",{"property":"og:locale","content":"om"}]
f:["$","meta","12",{"property":"og:image","content":"https://asfagro.com/asf-logo.png"}]
10:["$","meta","13",{"property":"og:type","content":"website"}]
11:["$","meta","14",{"name":"twitter:card","content":"summary_large_image"}]
12:["$","meta","15",{"name":"twitter:title","content":"Nyaatni Qulqullina Qabu Sarara Gatii Beeladaa Keessatti Maaliif Barbaachisaa Ta'e"}]
13:["$","meta","16",{"name":"twitter:description","content":"Toʼannoonni qulqullinaa fi ogeeyyiin laaboraatorii ASF meeshaa jalqabaa walitti qabuu irraa hanga nyaata xumurame qonnaan bultoota Itoophiyaa gaʼutti, sadarkaa hunda irratti sadarkaa oomishaa deeggaru."}]
14:["$","meta","17",{"name":"twitter:image","content":"https://asfagro.com/asf-logo.png"}]
15:["$","link","18",{"rel":"icon","href":"/asf-logo.png"}]
16:["$","$L20","19",{}]
17:["$","meta",null,{"name":"next-size-adjust","content":""}]
19:["$","$1","c",{"children":[null,["$","$L21",null,{"parallelRouterKey":"children","template":["$","$L22",null,{}]}]]}]
1c:["$","$1","c",{"children":[null,["$","$L21",null,{"parallelRouterKey":"children","template":["$","$L22",null,{}]}]]}]
1f:true
7:300
7:C
1e:0
18:"$undefined"
1a:"$undefined"
1d:"$undefined"
6:"$undefined"
