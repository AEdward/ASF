1:"$Sreact.fragment"
2:I[77105,["/_next/static/chunks/2dru2glu73-eh.js","/_next/static/chunks/14xmgymk1sega.js"],"default"]
3:I[97367,["/_next/static/chunks/3fntmmi971322.js"],"OutletBoundary"]
4:"$Sreact.suspense"
8:I[97367,["/_next/static/chunks/3fntmmi971322.js"],"ViewportBoundary"]
9:I[97367,["/_next/static/chunks/3fntmmi971322.js"],"MetadataBoundary"]
7:X
1c:X
1c:C
0:{"buildId":"fHhRWd-NoCwSpf___tmoY","data":[{"rsc":["$","$1","c",{"children":[["$","main",null,{"children":[["$","script",null,{"type":"application/ld+json","dangerouslySetInnerHTML":{"__html":"{\"@context\":\"https://schema.org\",\"@type\":\"Article\",\"headline\":\"Boqonnaa Itti Aanu ASF Paarkii Warshaalee Qonnaa Walitti Qindaa'e Bulbulaa keessatti\",\"description\":\"Guraandhala 2023, ASF Paarkii Warshaalee Qonnaa Walitti Qindaaʼe Bulbulaa waliin walii galtee investimentii lafa heektaara 271 irratti mallatteesse, kiiloomeetira 160 kibba Finfinnee, kanaanis boqonnaa guddina itti aanuuf hundeeffama kaaʼe.\",\"url\":\"https://asfagro.com/om/blog/next-chapter-at-bulbula\",\"publisher\":{\"@type\":\"Organization\",\"name\":\"ASF Agro Industry\",\"logo\":{\"@type\":\"ImageObject\",\"url\":\"https://asfagro.com/asf-logo.png\"}}}"}}],["$","script",null,{"type":"application/ld+json","dangerouslySetInnerHTML":{"__html":"{\"@context\":\"https://schema.org\",\"@type\":\"BreadcrumbList\",\"itemListElement\":[{\"@type\":\"ListItem\",\"position\":1,\"name\":\"Fuula Jalqabaa\",\"item\":\"https://asfagro.com/om\"},{\"@type\":\"ListItem\",\"position\":2,\"name\":\"Oduu fi Barreeffama\",\"item\":\"https://asfagro.com/om/blog\"},{\"@type\":\"ListItem\",\"position\":3,\"name\":\"Boqonnaa Itti Aanu ASF Paarkii Warshaalee Qonnaa Walitti Qindaa'e Bulbulaa keessatti\",\"item\":\"https://asfagro.com/om/blog/next-chapter-at-bulbula\"}]}"}}],["$","section",null,{"className":"bg-[linear-gradient(135deg,#f5fff0,#fffaf0)] py-20","children":["$","div",null,{"className":"mx-auto max-w-4xl px-5 lg:px-8","children":[["$","$L2",null,{"href":"/om/blog","localeCookie":{"name":"NEXT_LOCALE","sameSite":"lax"},"className":"text-sm font-bold text-green-700","children":"← Gara Oduu fi Barreeffama deebi'i"}],["$","div",null,{"className":"mb-4 flex items-center gap-2 text-xs font-black uppercase tracking-[.15em] text-green-700","children":[["$","span",null,{"className":"h-1 w-7 rounded bg-[#f5a617]"}],"Babal'ina"]}],["$","h1",null,{"className":"max-w-3xl text-4xl font-black tracking-tight sm:text-5xl","children":"Boqonnaa Itti Aanu ASF Paarkii Warshaalee Qonnaa Walitti Qindaa'e Bulbulaa keessatti"}]]}]}],"$undefined",["$","section",null,{"className":"py-16","children":["$","div",null,{"className":"mx-auto max-w-4xl px-5 lg:px-8","children":["$","div",null,{"className":"whitespace-pre-line text-lg leading-8 text-slate-700","children":"Guraandhala 2023, ASF Paarkii Warshaalee Qonnaa Walitti Qindaaʼe Bulbulaa waliin walii galtee investimentii lafa heektaara 271 irratti mallatteesse, kiiloomeetira 160 kibba Finfinnee, kanaanis boqonnaa guddina itti aanuuf hundeeffama kaaʼe."}]}]}]]}],null,["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":"$@6","staleTime":"$7","varyParams":null},{"rsc":["$","$1","h",{"children":[null,["$","$L8",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L9",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"Boqonnaa Itti Aanu ASF Paarkii Warshaalee Qonnaa Walitti Qindaa'e Bulbulaa keessatti | ASF Agro Industry"}],["$","meta","1",{"name":"description","content":"Guraandhala 2023, ASF Paarkii Warshaalee Qonnaa Walitti Qindaaʼe Bulbulaa waliin walii galtee investimentii lafa heektaara 271 irratti mallatteesse, kiiloomeetira 160 kibba Finfinnee, kanaanis boqonnaa guddina itti aanuuf hundeeffama kaaʼe."}],["$","link","2",{"rel":"canonical","href":"https://asfagro.com/om/blog/next-chapter-at-bulbula"}],["$","link","3",{"rel":"alternate","hrefLang":"en","href":"https://asfagro.com/en/blog/next-chapter-at-bulbula"}],["$","link","4",{"rel":"alternate","hrefLang":"am","href":"https://asfagro.com/am/blog/next-chapter-at-bulbula"}],["$","link","5",{"rel":"alternate","hrefLang":"om","href":"https://asfagro.com/om/blog/next-chapter-at-bulbula"}],"$La","$Lb","$Lc","$Ld","$Le","$Lf","$L10","$L11","$L12","$L13","$L14","$L15","$L16","$L17"]}]}]}],"$L18"]}],"isPartial":"$@19","staleTime":"$7","varyParams":null},{"rsc":"$L1a","isPartial":"$@1b","staleTime":"$7","varyParams":"$1c"},{"rsc":"$L1d","isPartial":"$@1e","staleTime":"$7","varyParams":"$1c"}],"isUpgradeableISRFallback":false,"a":"$@1f","rootVaryParams":null,"needsRuntimeRequest":"$@20"}
21:I[27201,["/_next/static/chunks/3fntmmi971322.js"],"IconMark"]
22:I[39756,["/_next/static/chunks/3fntmmi971322.js"],"default"]
23:I[37457,["/_next/static/chunks/3fntmmi971322.js"],"default"]
5:null
a:["$","link","6",{"rel":"alternate","hrefLang":"x-default","href":"https://asfagro.com/en/blog/next-chapter-at-bulbula"}]
b:["$","meta","7",{"property":"og:title","content":"Boqonnaa Itti Aanu ASF Paarkii Warshaalee Qonnaa Walitti Qindaa'e Bulbulaa keessatti"}]
c:["$","meta","8",{"property":"og:description","content":"Guraandhala 2023, ASF Paarkii Warshaalee Qonnaa Walitti Qindaaʼe Bulbulaa waliin walii galtee investimentii lafa heektaara 271 irratti mallatteesse, kiiloomeetira 160 kibba Finfinnee, kanaanis boqonnaa guddina itti aanuuf hundeeffama kaaʼe."}]
d:["$","meta","9",{"property":"og:url","content":"https://asfagro.com/om/blog/next-chapter-at-bulbula"}]
e:["$","meta","10",{"property":"og:site_name","content":"ASF Agro Industry"}]
f:["$","meta","11",{"property":"og:locale","content":"om"}]
10:["$","meta","12",{"property":"og:image","content":"https://asfagro.com/asf-logo.png"}]
11:["$","meta","13",{"property":"og:type","content":"website"}]
12:["$","meta","14",{"name":"twitter:card","content":"summary_large_image"}]
13:["$","meta","15",{"name":"twitter:title","content":"Boqonnaa Itti Aanu ASF Paarkii Warshaalee Qonnaa Walitti Qindaa'e Bulbulaa keessatti"}]
14:["$","meta","16",{"name":"twitter:description","content":"Guraandhala 2023, ASF Paarkii Warshaalee Qonnaa Walitti Qindaaʼe Bulbulaa waliin walii galtee investimentii lafa heektaara 271 irratti mallatteesse, kiiloomeetira 160 kibba Finfinnee, kanaanis boqonnaa guddina itti aanuuf hundeeffama kaaʼe."}]
15:["$","meta","17",{"name":"twitter:image","content":"https://asfagro.com/asf-logo.png"}]
16:["$","link","18",{"rel":"icon","href":"/asf-logo.png"}]
17:["$","$L21","19",{}]
18:["$","meta",null,{"name":"next-size-adjust","content":""}]
1a:["$","$1","c",{"children":[null,["$","$L22",null,{"parallelRouterKey":"children","template":["$","$L23",null,{}]}]]}]
1d:["$","$1","c",{"children":[null,["$","$L22",null,{"parallelRouterKey":"children","template":["$","$L23",null,{}]}]]}]
20:true
7:300
7:C
1f:0
19:"$undefined"
1b:"$undefined"
1e:"$undefined"
6:"$undefined"
