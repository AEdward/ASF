module.exports=[57138,(a,b,c)=>{}];

//# sourceMappingURL=044u_web__next-internal_server_app_%5Blocale%5D_terms-of-service_page_actions_1-mrhxa.js.map