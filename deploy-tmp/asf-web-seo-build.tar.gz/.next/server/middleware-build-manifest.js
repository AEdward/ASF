globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/fHhRWd-NoCwSpf___tmoY/_buildManifest.js",
    "static/fHhRWd-NoCwSpf___tmoY/_ssgManifest.js",
    "static/fHhRWd-NoCwSpf___tmoY/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3s6nzrbk-8mnv.js",
    "static/chunks/19mx3mg6lkumu.js",
    "static/chunks/3kmozkq6tgqnz.js",
    "static/chunks/2-rtuqsgzmno4.js",
    "static/chunks/turbopack-2-vpl8jgjmkts.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
