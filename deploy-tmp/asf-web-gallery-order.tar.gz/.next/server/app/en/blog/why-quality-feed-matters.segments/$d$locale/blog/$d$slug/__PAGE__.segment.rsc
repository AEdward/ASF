1:"$Sreact.fragment"
2:I[77105,["/_next/static/chunks/2dru2glu73-eh.js","/_next/static/chunks/14xmgymk1sega.js"],"default"]
3:I[97367,["/_next/static/chunks/3fntmmi971322.js"],"OutletBoundary"]
4:"$Sreact.suspense"
8:I[97367,["/_next/static/chunks/3fntmmi971322.js"],"ViewportBoundary"]
9:I[97367,["/_next/static/chunks/3fntmmi971322.js"],"MetadataBoundary"]
7:X
19:X
19:C
0:{"buildId":"a3YsZGXnj1f33J8C2lqKw","data":[{"rsc":["$","$1","c",{"children":[["$","main",null,{"children":[["$","script",null,{"type":"application/ld+json","dangerouslySetInnerHTML":{"__html":"{\"@context\":\"https://schema.org\",\"@type\":\"Article\",\"headline\":\"Why quality feed matters across the livestock value chain\",\"description\":\"ASF's quality controllers and lab technicians support production standards at every stage, from raw material sourcing to the finished feed reaching Ethiopia's livestock farmers.\",\"url\":\"https://asfagro.com/en/blog/why-quality-feed-matters\",\"publisher\":{\"@type\":\"Organization\",\"name\":\"ASF Agro Industry\",\"logo\":{\"@type\":\"ImageObject\",\"url\":\"https://asfagro.com/asf-logo.png\"}}}"}}],["$","script",null,{"type":"application/ld+json","dangerouslySetInnerHTML":{"__html":"{\"@context\":\"https://schema.org\",\"@type\":\"BreadcrumbList\",\"itemListElement\":[{\"@type\":\"ListItem\",\"position\":1,\"name\":\"Home\",\"item\":\"https://asfagro.com/en\"},{\"@type\":\"ListItem\",\"position\":2,\"name\":\"News & Blog\",\"item\":\"https://asfagro.com/en/blog\"},{\"@type\":\"ListItem\",\"position\":3,\"name\":\"Why quality feed matters across the livestock value chain\",\"item\":\"https://asfagro.com/en/blog/why-quality-feed-matters\"}]}"}}],["$","section",null,{"className":"bg-[linear-gradient(135deg,#f5fff0,#fffaf0)] py-20","children":["$","div",null,{"className":"mx-auto max-w-4xl px-5 lg:px-8","children":[["$","$L2",null,{"href":"/en/blog","localeCookie":{"name":"NEXT_LOCALE","sameSite":"lax"},"className":"text-sm font-bold text-green-700","children":"← Back to News & Blog"}],["$","div",null,{"className":"mb-4 flex items-center gap-2 text-xs font-black uppercase tracking-[.15em] text-green-700","children":[["$","span",null,{"className":"h-1 w-7 rounded bg-[#f5a617]"}],"Feed & Nutrition"]}],["$","h1",null,{"className":"max-w-3xl text-4xl font-black tracking-tight sm:text-5xl","children":"Why quality feed matters across the livestock value chain"}]]}]}],"$undefined",["$","section",null,{"className":"py-16","children":["$","div",null,{"className":"mx-auto max-w-4xl px-5 lg:px-8","children":["$","div",null,{"className":"whitespace-pre-line text-lg leading-8 text-slate-700","children":"ASF's quality controllers and lab technicians support production standards at every stage, from raw material sourcing to the finished feed reaching Ethiopia's livestock farmers."}]}]}]]}],null,["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":"$@6","staleTime":"$7","varyParams":null},{"rsc":["$","$1","h",{"children":[null,["$","$L8",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L9",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"Why quality feed matters across the livestock value chain | ASF Agro Industry"}],["$","meta","1",{"name":"description","content":"ASF's quality controllers and lab technicians support production standards at every stage, from raw material sourcing to the finished feed reaching Ethiopia's livestock farmers."}],["$","link","2",{"rel":"canonical","href":"https://asfagro.com/en/blog/why-quality-feed-matters"}],["$","link","3",{"rel":"alternate","hrefLang":"en","href":"https://asfagro.com/en/blog/why-quality-feed-matters"}],["$","link","4",{"rel":"alternate","hrefLang":"am","href":"https://asfagro.com/am/blog/why-quality-feed-matters"}],["$","link","5",{"rel":"alternate","hrefLang":"om","href":"https://asfagro.com/om/blog/why-quality-feed-matters"}],["$","link","6",{"rel":"alternate","hrefLang":"x-default","href":"https://asfagro.com/en/blog/why-quality-feed-matters"}],["$","meta","7",{"property":"og:title","content":"Why quality feed matters across the livestock value chain"}],["$","meta","8",{"property":"og:description","content":"ASF's quality controllers and lab technicians support production standards at every stage, from raw material sourcing to the finished feed reaching Ethiopia's livestock farmers."}],"$La","$Lb","$Lc","$Ld","$Le","$Lf","$L10","$L11","$L12","$L13","$L14"]}]}]}],"$L15"]}],"isPartial":"$@16","staleTime":"$7","varyParams":null},{"rsc":"$L17","isPartial":"$@18","staleTime":"$7","varyParams":"$19"},{"rsc":"$L1a","isPartial":"$@1b","staleTime":"$7","varyParams":"$19"}],"isUpgradeableISRFallback":false,"a":"$@1c","rootVaryParams":null,"needsRuntimeRequest":"$@1d"}
1e:I[27201,["/_next/static/chunks/3fntmmi971322.js"],"IconMark"]
1f:I[39756,["/_next/static/chunks/3fntmmi971322.js"],"default"]
20:I[37457,["/_next/static/chunks/3fntmmi971322.js"],"default"]
5:null
a:["$","meta","9",{"property":"og:url","content":"https://asfagro.com/en/blog/why-quality-feed-matters"}]
b:["$","meta","10",{"property":"og:site_name","content":"ASF Agro Industry"}]
c:["$","meta","11",{"property":"og:locale","content":"en"}]
d:["$","meta","12",{"property":"og:image","content":"https://asfagro.com/asf-logo.png"}]
e:["$","meta","13",{"property":"og:type","content":"website"}]
f:["$","meta","14",{"name":"twitter:card","content":"summary_large_image"}]
10:["$","meta","15",{"name":"twitter:title","content":"Why quality feed matters across the livestock value chain"}]
11:["$","meta","16",{"name":"twitter:description","content":"ASF's quality controllers and lab technicians support production standards at every stage, from raw material sourcing to the finished feed reaching Ethiopia's livestock farmers."}]
12:["$","meta","17",{"name":"twitter:image","content":"https://asfagro.com/asf-logo.png"}]
13:["$","link","18",{"rel":"icon","href":"/asf-logo.png"}]
14:["$","$L1e","19",{}]
15:["$","meta",null,{"name":"next-size-adjust","content":""}]
17:["$","$1","c",{"children":[null,["$","$L1f",null,{"parallelRouterKey":"children","template":["$","$L20",null,{}]}]]}]
1a:["$","$1","c",{"children":[null,["$","$L1f",null,{"parallelRouterKey":"children","template":["$","$L20",null,{}]}]]}]
1d:true
7:300
7:C
1c:0
16:"$undefined"
18:"$undefined"
1b:"$undefined"
6:"$undefined"
