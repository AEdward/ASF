1:"$Sreact.fragment"
2:I[77105,["/_next/static/chunks/2dru2glu73-eh.js","/_next/static/chunks/14xmgymk1sega.js"],"default"]
3:I[5500,["/_next/static/chunks/2dru2glu73-eh.js","/_next/static/chunks/14xmgymk1sega.js"],"Image"]
4:I[97367,["/_next/static/chunks/3fntmmi971322.js"],"OutletBoundary"]
5:"$Sreact.suspense"
9:I[97367,["/_next/static/chunks/3fntmmi971322.js"],"ViewportBoundary"]
a:I[97367,["/_next/static/chunks/3fntmmi971322.js"],"MetadataBoundary"]
8:X
1e:X
1e:C
0:{"buildId":"a3YsZGXnj1f33J8C2lqKw","data":[{"rsc":["$","$1","c",{"children":[["$","main",null,{"children":[["$","script",null,{"type":"application/ld+json","dangerouslySetInnerHTML":{"__html":"{\"@context\":\"https://schema.org\",\"@type\":\"Product\",\"name\":\"የከብት ማድለብ መኖ\",\"description\":\"በASF የእንስሳት ምርት ትኩረት ውስጥ የተነደፈ መኖ።\",\"url\":\"https://asfagro.com/am/products/cattle-fattening-feed\",\"image\":[\"http://localhost:1692/uploads/cattle_fattening_feed_c4b601e758.webp\"],\"brand\":{\"@type\":\"Brand\",\"name\":\"ASF Agro Industry\"}}"}}],["$","script",null,{"type":"application/ld+json","dangerouslySetInnerHTML":{"__html":"{\"@context\":\"https://schema.org\",\"@type\":\"BreadcrumbList\",\"itemListElement\":[{\"@type\":\"ListItem\",\"position\":1,\"name\":\"መነሻ\",\"item\":\"https://asfagro.com/am\"},{\"@type\":\"ListItem\",\"position\":2,\"name\":\"ምርቶች\",\"item\":\"https://asfagro.com/am/products\"},{\"@type\":\"ListItem\",\"position\":3,\"name\":\"የከብት ማድለብ መኖ\",\"item\":\"https://asfagro.com/am/products/cattle-fattening-feed\"}]}"}}],["$","section",null,{"className":"bg-[linear-gradient(135deg,#f5fff0,#fffaf0)] py-20","children":["$","div",null,{"className":"mx-auto max-w-5xl px-5 lg:px-8","children":[["$","$L2",null,{"href":"/am/products","localeCookie":{"name":"NEXT_LOCALE","sameSite":"lax"},"className":"text-sm font-bold text-green-700","children":"← ወደ ምርቶች ተመለስ"}],["$","div",null,{"className":"mb-4 flex items-center gap-2 text-xs font-black uppercase tracking-[.15em] text-green-700","children":[["$","span",null,{"className":"h-1 w-7 rounded bg-[#f5a617]"}],"የአሁኑ"]}],["$","h1",null,{"className":"max-w-3xl text-4xl font-black tracking-tight sm:text-5xl","children":"የከብት ማድለብ መኖ"}],["$","p",null,{"className":"mt-6 max-w-2xl text-lg text-slate-600","children":"በASF የእንስሳት ምርት ትኩረት ውስጥ የተነደፈ መኖ።"}]]}]}],["$","section",null,{"className":"py-16","children":["$","div",null,{"className":"mx-auto grid max-w-5xl gap-12 px-5 lg:grid-cols-2 lg:px-8","children":[["$","div",null,{"children":["$","div",null,{"className":"relative aspect-square overflow-hidden rounded-3xl bg-white","children":["$","$L3",null,{"src":"http://localhost:1692/uploads/cattle_fattening_feed_c4b601e758.webp","alt":"የከብት ማድለብ መኖ — የASF አግሮ ኢንዱስትሪ የእንስሳት መኖ ምርት","fill":true,"className":"object-contain p-6"}]}]}],["$","div",null,{"children":[["$","ul",null,{"className":"space-y-3","children":[["$","li","የአሁኑ የተገለጸ አቅም፦ 200 ኩንታል/ቀን",{"className":"flex gap-3 text-slate-700","children":[["$","span",null,{"className":"mt-1 h-2 w-2 shrink-0 rounded-full bg-[#58c900]"}],"የአሁኑ የተገለጸ አቅም፦ 200 ኩንታል/ቀን"]}],["$","li","የ1ኛ ዓመት ዕቅድ፦ 60,000 ኩንታል",{"className":"flex gap-3 text-slate-700","children":[["$","span",null,{"className":"mt-1 h-2 w-2 shrink-0 rounded-full bg-[#58c900]"}],"የ1ኛ ዓመት ዕቅድ፦ 60,000 ኩንታል"]}],["$","li","የ3ኛ ዓመት ዕቅድ፦ 120,000 ኩንታል",{"className":"flex gap-3 text-slate-700","children":[["$","span",null,{"className":"mt-1 h-2 w-2 shrink-0 rounded-full bg-[#58c900]"}],"የ3ኛ ዓመት ዕቅድ፦ 120,000 ኩንታል"]}]]}],"$undefined",["$","div",null,{"className":"mt-10","children":["$","$L2",null,{"href":"/am/contact","localeCookie":"$0:data:0:rsc:props:children:0:props:children:2:props:children:props:children:0:props:localeCookie","className":"inline-flex rounded-xl px-5 py-3 text-sm font-extrabold bg-[#58c900] text-[#092713]","children":"የዋጋ ጥቆማ ይጠይቁ →"}]}]]}]]}]}],false]}],null,["$","$L4",null,{"children":["$","$5",null,{"name":"Next.MetadataOutlet","children":"$@6"}]}]]}],"isPartial":"$@7","staleTime":"$8","varyParams":null},{"rsc":["$","$1","h",{"children":[null,["$","$L9",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$La",null,{"children":["$","$5",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"የከብት ማድለብ መኖ | ASF Agro Industry"}],["$","meta","1",{"name":"description","content":"በASF የእንስሳት ምርት ትኩረት ውስጥ የተነደፈ መኖ።"}],["$","link","2",{"rel":"canonical","href":"https://asfagro.com/am/products/cattle-fattening-feed"}],["$","link","3",{"rel":"alternate","hrefLang":"en","href":"https://asfagro.com/en/products/cattle-fattening-feed"}],["$","link","4",{"rel":"alternate","hrefLang":"am","href":"https://asfagro.com/am/products/cattle-fattening-feed"}],"$Lb","$Lc","$Ld","$Le","$Lf","$L10","$L11","$L12","$L13","$L14","$L15","$L16","$L17","$L18","$L19"]}]}]}],"$L1a"]}],"isPartial":"$@1b","staleTime":"$8","varyParams":null},{"rsc":"$L1c","isPartial":"$@1d","staleTime":"$8","varyParams":"$1e"},{"rsc":"$L1f","isPartial":"$@20","staleTime":"$8","varyParams":"$1e"}],"isUpgradeableISRFallback":false,"a":"$@21","rootVaryParams":null,"needsRuntimeRequest":"$@22"}
23:I[27201,["/_next/static/chunks/3fntmmi971322.js"],"IconMark"]
24:I[39756,["/_next/static/chunks/3fntmmi971322.js"],"default"]
25:I[37457,["/_next/static/chunks/3fntmmi971322.js"],"default"]
6:null
b:["$","link","5",{"rel":"alternate","hrefLang":"om","href":"https://asfagro.com/om/products/cattle-fattening-feed"}]
c:["$","link","6",{"rel":"alternate","hrefLang":"x-default","href":"https://asfagro.com/en/products/cattle-fattening-feed"}]
d:["$","meta","7",{"property":"og:title","content":"የከብት ማድለብ መኖ"}]
e:["$","meta","8",{"property":"og:description","content":"በASF የእንስሳት ምርት ትኩረት ውስጥ የተነደፈ መኖ።"}]
f:["$","meta","9",{"property":"og:url","content":"https://asfagro.com/am/products/cattle-fattening-feed"}]
10:["$","meta","10",{"property":"og:site_name","content":"ASF Agro Industry"}]
11:["$","meta","11",{"property":"og:locale","content":"am"}]
12:["$","meta","12",{"property":"og:image","content":"http://localhost:1692/uploads/cattle_fattening_feed_c4b601e758.webp"}]
13:["$","meta","13",{"property":"og:type","content":"website"}]
14:["$","meta","14",{"name":"twitter:card","content":"summary_large_image"}]
15:["$","meta","15",{"name":"twitter:title","content":"የከብት ማድለብ መኖ"}]
16:["$","meta","16",{"name":"twitter:description","content":"በASF የእንስሳት ምርት ትኩረት ውስጥ የተነደፈ መኖ።"}]
17:["$","meta","17",{"name":"twitter:image","content":"http://localhost:1692/uploads/cattle_fattening_feed_c4b601e758.webp"}]
18:["$","link","18",{"rel":"icon","href":"/asf-logo.png"}]
19:["$","$L23","19",{}]
1a:["$","meta",null,{"name":"next-size-adjust","content":""}]
1c:["$","$1","c",{"children":[null,["$","$L24",null,{"parallelRouterKey":"children","template":["$","$L25",null,{}]}]]}]
1f:["$","$1","c",{"children":[null,["$","$L24",null,{"parallelRouterKey":"children","template":["$","$L25",null,{}]}]]}]
22:true
8:300
8:C
21:0
1b:"$undefined"
1d:"$undefined"
20:"$undefined"
7:"$undefined"
