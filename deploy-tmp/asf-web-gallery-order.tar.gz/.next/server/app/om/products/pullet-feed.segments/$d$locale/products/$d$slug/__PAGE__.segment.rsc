1:"$Sreact.fragment"
2:I[77105,["/_next/static/chunks/2dru2glu73-eh.js","/_next/static/chunks/14xmgymk1sega.js"],"default"]
3:I[5500,["/_next/static/chunks/2dru2glu73-eh.js","/_next/static/chunks/14xmgymk1sega.js"],"Image"]
4:I[97367,["/_next/static/chunks/3fntmmi971322.js"],"OutletBoundary"]
5:"$Sreact.suspense"
9:I[97367,["/_next/static/chunks/3fntmmi971322.js"],"ViewportBoundary"]
a:I[97367,["/_next/static/chunks/3fntmmi971322.js"],"MetadataBoundary"]
8:X
17:X
17:C
0:{"buildId":"a3YsZGXnj1f33J8C2lqKw","data":[{"rsc":["$","$1","c",{"children":[["$","main",null,{"children":[["$","script",null,{"type":"application/ld+json","dangerouslySetInnerHTML":{"__html":"{\"@context\":\"https://schema.org\",\"@type\":\"Product\",\"name\":\"Nyaata Pulleetii\",\"description\":\"Nyaata pulleetiif qophaa'e, kutaa nyaata lukkuu ASF keessaa.\",\"url\":\"https://asfagro.com/om/products/pullet-feed\",\"image\":[\"http://localhost:1692/uploads/pullet_feed_090fd1f068.webp\"],\"brand\":{\"@type\":\"Brand\",\"name\":\"ASF Agro Industry\"}}"}}],["$","script",null,{"type":"application/ld+json","dangerouslySetInnerHTML":{"__html":"{\"@context\":\"https://schema.org\",\"@type\":\"BreadcrumbList\",\"itemListElement\":[{\"@type\":\"ListItem\",\"position\":1,\"name\":\"Fuula Jalqabaa\",\"item\":\"https://asfagro.com/om\"},{\"@type\":\"ListItem\",\"position\":2,\"name\":\"Oomishaalee\",\"item\":\"https://asfagro.com/om/products\"},{\"@type\":\"ListItem\",\"position\":3,\"name\":\"Nyaata Pulleetii\",\"item\":\"https://asfagro.com/om/products/pullet-feed\"}]}"}}],["$","section",null,{"className":"bg-[linear-gradient(135deg,#f5fff0,#fffaf0)] py-20","children":["$","div",null,{"className":"mx-auto max-w-5xl px-5 lg:px-8","children":[["$","$L2",null,{"href":"/om/products","localeCookie":{"name":"NEXT_LOCALE","sameSite":"lax"},"className":"text-sm font-bold text-green-700","children":"← Gara Oomishaalee deebi'i"}],["$","div",null,{"className":"mb-4 flex items-center gap-2 text-xs font-black uppercase tracking-[.15em] text-green-700","children":[["$","span",null,{"className":"h-1 w-7 rounded bg-[#f5a617]"}],"AMMA"]}],["$","h1",null,{"className":"max-w-3xl text-4xl font-black tracking-tight sm:text-5xl","children":"Nyaata Pulleetii"}],["$","p",null,{"className":"mt-6 max-w-2xl text-lg text-slate-600","children":"Nyaata pulleetiif qophaa'e, kutaa nyaata lukkuu ASF keessaa."}]]}]}],["$","section",null,{"className":"py-16","children":["$","div",null,{"className":"mx-auto grid max-w-5xl gap-12 px-5 lg:grid-cols-2 lg:px-8","children":[["$","div",null,{"children":["$","div",null,{"className":"relative aspect-square overflow-hidden rounded-3xl bg-white","children":["$","$L3",null,{"src":"http://localhost:1692/uploads/pullet_feed_090fd1f068.webp","alt":"Nyaata Pulleetii — Oomisha Nyaata Beeladaa ASF Agro Industry","fill":true,"className":"object-contain p-6"}]}]}],["$","div",null,{"children":[false,"$undefined",["$","div",null,{"className":"mt-10","children":["$","$L2",null,{"href":"/om/contact","localeCookie":"$0:data:0:rsc:props:children:0:props:children:2:props:children:props:children:0:props:localeCookie","className":"inline-flex rounded-xl px-5 py-3 text-sm font-extrabold bg-[#58c900] text-[#092713]","children":"Gaaffii gatii gaafadhaa →"}]}]]}]]}]}],false]}],null,["$","$L4",null,{"children":["$","$5",null,{"name":"Next.MetadataOutlet","children":"$@6"}]}]]}],"isPartial":"$@7","staleTime":"$8","varyParams":null},{"rsc":["$","$1","h",{"children":[null,["$","$L9",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$La",null,{"children":["$","$5",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"Nyaata Pulleetii | ASF Agro Industry"}],["$","meta","1",{"name":"description","content":"Nyaata pulleetiif qophaa'e, kutaa nyaata lukkuu ASF keessaa."}],["$","link","2",{"rel":"canonical","href":"https://asfagro.com/om/products/pullet-feed"}],["$","link","3",{"rel":"alternate","hrefLang":"en","href":"https://asfagro.com/en/products/pullet-feed"}],["$","link","4",{"rel":"alternate","hrefLang":"am","href":"https://asfagro.com/am/products/pullet-feed"}],["$","link","5",{"rel":"alternate","hrefLang":"om","href":"https://asfagro.com/om/products/pullet-feed"}],["$","link","6",{"rel":"alternate","hrefLang":"x-default","href":"https://asfagro.com/en/products/pullet-feed"}],["$","meta","7",{"property":"og:title","content":"Nyaata Pulleetii"}],["$","meta","8",{"property":"og:description","content":"Nyaata pulleetiif qophaa'e, kutaa nyaata lukkuu ASF keessaa."}],["$","meta","9",{"property":"og:url","content":"https://asfagro.com/om/products/pullet-feed"}],["$","meta","10",{"property":"og:site_name","content":"ASF Agro Industry"}],["$","meta","11",{"property":"og:locale","content":"om"}],"$Lb","$Lc","$Ld","$Le","$Lf","$L10","$L11","$L12"]}]}]}],"$L13"]}],"isPartial":"$@14","staleTime":"$8","varyParams":null},{"rsc":"$L15","isPartial":"$@16","staleTime":"$8","varyParams":"$17"},{"rsc":"$L18","isPartial":"$@19","staleTime":"$8","varyParams":"$17"}],"isUpgradeableISRFallback":false,"a":"$@1a","rootVaryParams":null,"needsRuntimeRequest":"$@1b"}
1c:I[27201,["/_next/static/chunks/3fntmmi971322.js"],"IconMark"]
1d:I[39756,["/_next/static/chunks/3fntmmi971322.js"],"default"]
1e:I[37457,["/_next/static/chunks/3fntmmi971322.js"],"default"]
6:null
b:["$","meta","12",{"property":"og:image","content":"http://localhost:1692/uploads/pullet_feed_090fd1f068.webp"}]
c:["$","meta","13",{"property":"og:type","content":"website"}]
d:["$","meta","14",{"name":"twitter:card","content":"summary_large_image"}]
e:["$","meta","15",{"name":"twitter:title","content":"Nyaata Pulleetii"}]
f:["$","meta","16",{"name":"twitter:description","content":"Nyaata pulleetiif qophaa'e, kutaa nyaata lukkuu ASF keessaa."}]
10:["$","meta","17",{"name":"twitter:image","content":"http://localhost:1692/uploads/pullet_feed_090fd1f068.webp"}]
11:["$","link","18",{"rel":"icon","href":"/asf-logo.png"}]
12:["$","$L1c","19",{}]
13:["$","meta",null,{"name":"next-size-adjust","content":""}]
15:["$","$1","c",{"children":[null,["$","$L1d",null,{"parallelRouterKey":"children","template":["$","$L1e",null,{}]}]]}]
18:["$","$1","c",{"children":[null,["$","$L1d",null,{"parallelRouterKey":"children","template":["$","$L1e",null,{}]}]]}]
1b:true
8:300
8:C
1a:0
14:"$undefined"
16:"$undefined"
19:"$undefined"
7:"$undefined"
