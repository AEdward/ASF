:HL["/_next/static/chunks/091d8xk9dnzee.css","style"]
:HL["/_next/static/media/276ff8de80749a43-s.p.29e-66-z_wi5x.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"locale","param":{"type":"d","key":"om","siblings":["api"]},"prefetchHints":4144,"slots":{"children":{"name":"about","param":null,"prefetchHints":4160,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}}}},"staleTime":300,"buildId":"a3YsZGXnj1f33J8C2lqKw"}
